import hashlib
import re
from collections import defaultdict
from copy import deepcopy
from dataclasses import dataclass
from typing import cast

from jsonschema import Draft202012Validator
from mcp.types import Tool
from openai.types.chat import ChatCompletionToolParam
from pydantic import JsonValue, TypeAdapter


JsonObject = dict[str, JsonValue]
_JSON_OBJECT_ADAPTER = TypeAdapter(JsonObject)
_MODEL_NAME = re.compile(r"[^A-Za-z0-9_-]")
_RESERVED_NAMES = frozenset({"propose_answer", "review_candidate"})


@dataclass(frozen=True)
class ModelTool:
    model_name: str
    arena_name: str
    input_schema: JsonObject
    definition: ChatCompletionToolParam
    inject_agent_id: bool


class ToolArgumentError(ValueError):
    pass


def _base_name(name: str) -> str:
    normalized = _MODEL_NAME.sub("_", name).strip("_") or "tool"
    if len(normalized) <= 64:
        return normalized
    suffix = hashlib.sha256(name.encode("utf-8")).hexdigest()[:8]
    return f"{normalized[:55]}_{suffix}"


def _schema_for_model(tool: Tool) -> tuple[JsonObject, bool]:
    schema = _JSON_OBJECT_ADAPTER.validate_python(tool.inputSchema)
    properties = schema.get("properties")
    inject_agent_id = isinstance(properties, dict) and "agent_id" in properties
    if inject_agent_id:
        visible_schema = deepcopy(schema)
        visible_properties = visible_schema.get("properties")
        if isinstance(visible_properties, dict):
            visible_properties.pop("agent_id", None)
        required = visible_schema.get("required")
        if isinstance(required, list):
            visible_schema["required"] = [key for key in required if key != "agent_id"]
        return visible_schema, True
    return schema, False


def build_model_tools(
    tool_defs: list[Tool],
    *,
    excluded_tool_names: frozenset[str] = frozenset(),
) -> dict[str, ModelTool]:
    candidates: dict[str, list[Tool]] = defaultdict(list)
    for tool in tool_defs:
        if tool.name not in excluded_tool_names:
            candidates[_base_name(tool.name)].append(tool)

    registry: dict[str, ModelTool] = {}
    for base_name, tools in candidates.items():
        for tool in tools:
            digest = hashlib.sha256(tool.name.encode("utf-8")).hexdigest()[:8]
            model_name = base_name
            if len(tools) > 1 or model_name in _RESERVED_NAMES:
                model_name = f"{base_name[:55]}_{digest}"
            if model_name in registry:
                raise ValueError(f"MCP tool names collide after normalization: {tool.name}")

            input_schema, inject_agent_id = _schema_for_model(tool)
            function: dict[str, JsonValue] = {
                "name": model_name,
                "description": str(tool.description or tool.name),
                "parameters": input_schema,
            }
            registry[model_name] = ModelTool(
                model_name=model_name,
                arena_name=tool.name,
                input_schema=_JSON_OBJECT_ADAPTER.validate_python(tool.inputSchema),
                definition=cast(
                    ChatCompletionToolParam,
                    {"type": "function", "function": function},
                ),
                inject_agent_id=inject_agent_id,
            )
    return registry


def validate_tool_arguments(
    tool: ModelTool,
    raw_arguments: str,
    *,
    agent_id: str,
) -> JsonObject:
    try:
        arguments = _JSON_OBJECT_ADAPTER.validate_json(raw_arguments)
    except ValueError as exc:
        raise ToolArgumentError("Tool arguments must be a JSON object") from exc

    supplied_agent_id = arguments.get("agent_id")
    if supplied_agent_id is not None and supplied_agent_id != agent_id:
        raise ToolArgumentError("Model may not choose a different agent_id")
    arguments.pop("agent_id", None)
    if tool.inject_agent_id:
        arguments["agent_id"] = agent_id

    validator = Draft202012Validator(tool.input_schema)
    errors = sorted(validator.iter_errors(arguments), key=lambda error: list(error.path))
    if errors:
        message = "; ".join(error.message for error in errors[:3])
        raise ToolArgumentError(f"Invalid arguments for {tool.arena_name}: {message}")
    return arguments