#!/usr/bin/env python3
"""Ctrl Alt Defeat Agent Gauntlet entry point.

    cd Agent-Gauntlet-Starter-Kit && .venv/bin/python examples/ours/agent.py
"""

import asyncio

from gauntlet.runner import run

if __name__ == "__main__":
    asyncio.run(run())
