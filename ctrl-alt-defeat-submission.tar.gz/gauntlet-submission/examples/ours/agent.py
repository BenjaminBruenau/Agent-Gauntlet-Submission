#!/usr/bin/env python3

import asyncio
import os
import sys
from pathlib import Path

from dotenv import load_dotenv

KIT_ROOT = Path(__file__).resolve().parents[2]
if str(KIT_ROOT) not in sys.path:
    sys.path.insert(0, str(KIT_ROOT))

load_dotenv(KIT_ROOT / ".env")

from arena_clients.config import agent_id_problem
from my_strategy import MyStrategy
from runtime import run_agent


if __name__ == "__main__":
    strategy = MyStrategy()
    os.environ["AGENT_ID"] = (
        os.getenv("AGENT_ID") or strategy.agent_id
    ).strip()
    id_problem = agent_id_problem(os.environ["AGENT_ID"])
    if id_problem:
        raise SystemExit(id_problem)
    os.environ["AGENT_NAME"] = (
        os.getenv("AGENT_NAME") or strategy.agent_name
    ).strip()
    asyncio.run(run_agent())
