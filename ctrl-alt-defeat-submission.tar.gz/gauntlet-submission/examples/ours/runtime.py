import asyncio
import json
import os
import time
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import cast

from mcp.types import Tool
from openai import AsyncOpenAI
from pydantic import JsonValue, TypeAdapter

from arena_clients import (
    ArenaConnectionError,
    HttpArenaClient,
    McpArenaClient,
    ensure_connected,
    get_arena_api_key,
    get_api_base,
    get_mcp_url,
    get_proxy_host,
    monitor_session,
)
from arena_clients.config import agent_id_problem
from arena_clients.display import challenge_record, print_challenge, save_run_record
from arena_clients.mcp_client import ChallengeInfo, ImageChallengeInfo, McpArenaError, build_image_tool_arguments
from arena_clients.outputs import missing_tools_note, save_submitted_image, submission_summary_lines
from arena_clients.proxy_headers import build_proxy_headers, resolve_usage_scope
from base_strategy import ChallengeContext
from model_selector import fetch_available_models, require_explicit_model
from model_tools import JsonObject, build_model_tools, validate_tool_arguments
from my_strategy import MyStrategy
from react import ReactConfig, ReactOutcome, run_react_loop


_JSON_OBJECT_ADAPTER = TypeAdapter(JsonObject)
KIT_ROOT = Path(__file__).resolve().parents[2]


def _required_tools(value: object) -> frozenset[str]:
    if not isinstance(value, list):
        return frozenset()
    return frozenset(item.strip() for item in value if isinstance(item, str) and item.strip())


def _phase_poll_interval() -> float:
    raw = os.getenv("ARENA_PHASE_POLL_INTERVAL_S", "0.5")
    interval = float(raw)
    if interval <= 0:
        raise ValueError("ARENA_PHASE_POLL_INTERVAL_S must be positive")
    return interval


async def _wait_for_running(client: HttpArenaClient) -> float:
    latencies: list[float] = []
    poll_interval_s = _phase_poll_interval()
    waiting_logged = False
    while True:
        started = time.monotonic()
        competition = await asyncio.to_thread(client.get_competition)
        latencies.append(time.monotonic() - started)
        phase_value = competition.get("phase")
        if not isinstance(phase_value, str) or not phase_value.strip():
            raise RuntimeError("Competition response did not include a phase")
        phase = phase_value.strip().casefold()
        if phase == "running":
            return max(latencies)
        if phase in {"finished", "complete", "completed", "stopped"}:
            raise RuntimeError(f"Competition is already {phase}")
        if not waiting_logged:
            print(f"Waiting for GO (competition phase: {phase})...", flush=True)
            waiting_logged = True
        await asyncio.sleep(poll_interval_s)


def _challenge_prompt(
    challenge: ChallengeInfo,
    clues: list[str],
    required: frozenset[str],
    controller_called: frozenset[str],
) -> str:
    clue_text = "\n".join(f"- {clue}" for clue in clues) or "- No separate clues were returned."
    completed = required & controller_called
    remaining = required - controller_called
    completed_text = ", ".join(sorted(completed)) or "None."
    remaining_text = ", ".join(sorted(remaining)) or "None."
    return (
        f"Challenge type: {challenge.challenge_type}\n"
        f"Description: {challenge.description}\n"
        f"Rules and exact output requirements: {challenge.rules}\n"
        f"Required tools already called by the controller: {completed_text}\n"
        f"Required tools still to call: {remaining_text}\n\n"
        f"Clues:\n{clue_text}\n\n"
        "Do not try to call tools already called by the controller; their data is provided above. "
        "Use any remaining required tools before proposing a candidate. Propose only the exact answer, "
        "then review every clue and output rule."
    )


def _select_model(
    strategy: MyStrategy,
    *,
    challenge_type: str,
    description: str,
    rules: str,
    max_time_s: int,
    available_models: list[str],
) -> tuple[str, ChallengeContext]:
    context = ChallengeContext(
        challenge_type=challenge_type,
        description=description,
        challenge_text=description,
        rules=rules,
        max_time_s=max_time_s,
        available_models=available_models,
        time_remaining_s=float(max_time_s),
    )
    ranked = strategy.rank_models(context, available_models)
    selected = strategy.pick_model("solve", ranked, context)
    return require_explicit_model(selected, available_models, source="ours agent"), context


async def _broadcast(client: HttpArenaClient, agent_id: str, text: str) -> None:
    accepted = await asyncio.to_thread(client.broadcast_thought, agent_id, text)
    if not accepted:
        raise RuntimeError("Arena did not accept the required progress thought")


async def _broadcast_image(
    client: McpArenaClient,
    agent_id: str,
    text: str,
) -> None:
    result = await client.broadcast_image_thought(text, agent_id)
    if result.get("accepted") is False:
        raise RuntimeError("Arena did not accept the required image progress thought")


async def _execute_tool(
    mcp_client: McpArenaClient,
    name: str,
    arguments: JsonObject,
) -> JsonObject:
    result = await mcp_client.call_tool(name, arguments)
    normalized = _JSON_OBJECT_ADAPTER.validate_python(result)
    if "error" in normalized:
        raise McpArenaError(str(normalized["error"]))
    return normalized


def _metrics(outcome: ReactOutcome, model: str) -> dict[str, JsonValue]:
    metrics: dict[str, JsonValue] = {
        "model_name": model,
        "agent_elapsed_ms": outcome.elapsed_ms,
        "react_steps": outcome.steps,
        "stop_reason": outcome.stop_reason,
    }
    if outcome.prompt_tokens is not None:
        metrics["prompt_tokens"] = outcome.prompt_tokens
    if outcome.completion_tokens is not None:
        metrics["completion_tokens"] = outcome.completion_tokens
    if outcome.total_tokens is not None:
        metrics["total_tokens"] = outcome.total_tokens
    return metrics


async def _submit_text(
    http_client: HttpArenaClient,
    agent_id: str,
    answer: str,
    metrics: dict[str, JsonValue],
) -> object:
    try:
        return await asyncio.to_thread(
            http_client.submit,
            agent_id,
            answer,
            cast(dict[str, object], metrics),
            "text",
        )
    except ArenaConnectionError:
        return await asyncio.to_thread(
            http_client.submit,
            agent_id,
            answer,
            cast(dict[str, object], metrics),
            "text",
        )


async def _run_text_challenge(
    *,
    challenge: ChallengeInfo,
    clues: list[str],
    required: frozenset[str],
    tool_defs: list[Tool],
    mcp_client: McpArenaClient,
    http_client: HttpArenaClient,
    llm_client: AsyncOpenAI,
    model: str,
    agent_id: str,
    model_context: ChallengeContext,
    deadline: float,
    submit_reserve_s: float,
    strategy: MyStrategy,
) -> tuple[str, ReactOutcome, object]:
    print(f"Calling {model} with the ReAct loop...", flush=True)
    controller_called_tool_names = mcp_client.called_tool_names
    await _broadcast(http_client, agent_id, "Reading the challenge and planning the next tool calls.")
    prompt = _challenge_prompt(challenge, clues, required, controller_called_tool_names)
    strategy_notes = str(strategy.text_strategy_notes or "").strip()
    if strategy_notes:
        prompt = f"{prompt}\n\nStrategy notes: {strategy_notes}"

    async def report_progress(message: str) -> None:
        print(f"   {message}", flush=True)
        await _broadcast(http_client, agent_id, message)

    outcome = await run_react_loop(
        client=llm_client,
        model=model,
        challenge_prompt=prompt,
        tool_defs=tool_defs,
        execute_tool=lambda name, arguments: _execute_tool(mcp_client, name, arguments),
        agent_id=agent_id,
        controller_called_tool_names=controller_called_tool_names,
        required_tool_names=required,
        deadline=deadline,
        config=ReactConfig(
            max_tokens=int(strategy.get_llm_params(model_context).get("max_tokens", 0)),
            submit_reserve_s=submit_reserve_s,
        ),
        progress=report_progress,
    )
    candidate = outcome.candidate
    answer = candidate.answer if candidate is not None else ""
    missing_required = required - outcome.used_tool_names
    known_invalid = candidate is not None and not candidate.reviewed and bool(candidate.issues)
    if answer:
        print(f"Candidate reviewed after {outcome.steps} ReAct turn(s).", flush=True)
        print("Submitting text answer...", flush=True)
        await asyncio.to_thread(http_client.save_draft, agent_id, answer, "ReAct candidate")
    result = (
        await _submit_text(http_client, agent_id, answer, _metrics(outcome, model))
        if answer and not missing_required and not known_invalid
        else None
    )
    return answer, outcome, result


def _image_tool_arguments(
    tool: Tool,
    *,
    agent_id: str,
    image_uri: str = "",
    prompt: str = "",
    question: str = "",
    model: str,
    llm_api_key: str,
    arena_api_key: str,
) -> JsonObject:
    schema = _JSON_OBJECT_ADAPTER.validate_python(tool.inputSchema)
    properties = schema.get("properties")
    if not isinstance(properties, dict):
        raise RuntimeError(f"Discovered tool {tool.name!r} has no object input schema")
    values: dict[str, JsonValue] = {}
    for key, definition in properties.items():
        description = definition.get("description", "") if isinstance(definition, dict) else ""
        field_text = f"{key} {description}".casefold()
        if image_uri and "image" in field_text and any(term in field_text for term in ("uri", "url", "source", "input")):
            values[key] = image_uri
        elif question and any(term in field_text for term in ("question", "query", "analysis request")):
            values[key] = question
        elif prompt and any(term in field_text for term in ("prompt", "instruction", "edit request", "generation request")):
            values[key] = prompt
    values.update(
        build_image_tool_arguments(
            [tool],
            tool.name,
            selected_model=model,
            llm_api_key=llm_api_key,
            arena_api_key=arena_api_key,
        )
    )
    registry = build_model_tools([tool])
    model_tool = next(iter(registry.values()))
    return validate_tool_arguments(model_tool, json.dumps(values), agent_id=agent_id)


async def _call_image_tool(
    mcp_client: McpArenaClient,
    tool_defs: list[Tool],
    tool: Tool,
    *,
    agent_id: str,
    model: str,
    llm_api_key: str,
    arena_api_key: str,
    image_uri: str = "",
    prompt: str = "",
    question: str = "",
) -> JsonObject:
    arguments = _image_tool_arguments(
        tool,
        agent_id=agent_id,
        image_uri=image_uri,
        prompt=prompt,
        question=question,
        model=model,
        llm_api_key=llm_api_key,
        arena_api_key=arena_api_key,
    )
    return await _execute_tool(mcp_client, tool.name, arguments)


def _image_capability(tool: Tool) -> str | None:
    schema = _JSON_OBJECT_ADAPTER.validate_python(tool.inputSchema)
    properties = schema.get("properties")
    property_text = ""
    if isinstance(properties, dict):
        property_text = " ".join(
            f"{key} {value.get('description', '')}"
            for key, value in properties.items()
            if isinstance(value, dict)
        )
    description = f"{tool.name} {tool.description or ''} {property_text}".casefold()
    if "image" not in description:
        return None
    if any(term in description for term in ("analyze", "analyse", "inspect", "describe")):
        return "analyze"
    if any(term in description for term in ("edit", "modify", "transform")):
        return "edit"
    if any(term in description for term in ("generate", "create", "render")):
        return "generate"
    return None


def _discover_image_operations(tool_defs: list[Tool]) -> dict[str, Tool]:
    operations: dict[str, Tool] = {}
    for tool in tool_defs:
        capability = _image_capability(tool)
        if capability is not None and capability not in operations:
            operations[capability] = tool
    return operations


async def _run_image_challenge(
    *,
    challenge: ImageChallengeInfo,
    tool_defs: list[Tool],
    mcp_client: McpArenaClient,
    http_client: HttpArenaClient,
    strategy: MyStrategy,
    model: str,
    agent_id: str,
    llm_api_key: str,
    arena_api_key: str,
    deadline: float,
) -> tuple[str, dict[str, JsonValue], object]:
    context = ChallengeContext(
        challenge_type=challenge.challenge_type,
        difficulty=challenge.difficulty,
        challenge_text=challenge.description,
        description=challenge.description,
        rules="\n".join(part for part in (challenge.prompt, challenge.reference_notes) if part),
        time_remaining_s=max(0.0, deadline - time.monotonic()),
        max_time_s=challenge.max_time_s,
        available_models=[model],
        image_url=challenge.input_image_uri or None,
    )
    prompt = strategy.build_image_prompt(context)
    operations = _discover_image_operations(tool_defs)
    selected_operation = "edit" if challenge.input_image_uri else "generate"
    output_tool = operations.get(selected_operation)
    analysis_tool = operations.get("analyze")
    if output_tool is None:
        raise RuntimeError("No discovered image output tool can satisfy this challenge")

    await _broadcast_image(
        mcp_client,
        agent_id,
        "Planning the image operation from the discovered tool schemas.",
    )
    analysis_text = ""
    sequence: list[str] = []
    if analysis_tool is not None and challenge.input_image_uri:
        sequence.append(analysis_tool.name)
        print(f"Analyzing source with {analysis_tool.name}...", flush=True)
        try:
            analysis = await _call_image_tool(
                mcp_client,
                tool_defs,
                analysis_tool,
                agent_id=agent_id,
                model=model,
                llm_api_key=llm_api_key,
                arena_api_key=arena_api_key,
                image_uri=challenge.input_image_uri,
                question=prompt,
            )
            analysis_text = str(analysis.get("text") or "").strip()
            if not analysis_text:
                print("Image analysis returned no text; continuing with the image edit.", flush=True)
        except McpArenaError as exc:
            print(
                f"Image analysis failed ({str(exc)[:240]}); continuing with the image edit.",
                flush=True,
            )
        if analysis_text:
            prompt = f"{prompt}\n\nSource image notes: {analysis_text[:1200]}"

    print(f"Running image operation with {output_tool.name}...", flush=True)
    output = await _call_image_tool(
        mcp_client,
        tool_defs,
        output_tool,
        agent_id=agent_id,
        model=model,
        llm_api_key=llm_api_key,
        arena_api_key=arena_api_key,
        image_uri=challenge.input_image_uri,
        prompt=prompt,
    )
    sequence.append(output_tool.name)
    image_uri = output.get("image_uri")
    if not isinstance(image_uri, str) or not image_uri.strip():
        raise RuntimeError("Image tool returned no image_uri; refusing to submit a placeholder")

    rationale = f"Applied the requested change: {challenge.prompt[:500]}".strip()
    if challenge.reference_notes:
        rationale += f" Preserved the stated constraints: {challenge.reference_notes[:400]}"
    if analysis_text:
        rationale += " Checked the source image with the discovered image-analysis tool."
    print("Submitting image output...", flush=True)
    result = await mcp_client.submit_image(
        agent_id=agent_id,
        image_uri=image_uri,
        client_metrics={"model_name": model, "tool_count": len(sequence)},
        rationale=rationale,
    )
    missing = set(challenge.required_tools) - mcp_client.called_tool_names
    if missing:
        print("Required image tools not called: " + ", ".join(sorted(missing)), flush=True)
    return image_uri, {"model": model, "tool_sequence": sequence, "rationale": rationale}, result


async def run_agent() -> None:
    strategy = MyStrategy()
    agent_id = (os.getenv("AGENT_ID") or strategy.agent_id).strip()
    agent_name = (os.getenv("AGENT_NAME") or strategy.agent_name).strip()
    if not agent_id or not agent_name:
        raise ValueError("AGENT_ID and AGENT_NAME must be configured")
    problem = agent_id_problem(agent_id)
    if problem:
        raise ValueError(problem)

    print(f"Agent {agent_name} starting (ID: {agent_id}).", flush=True)
    await asyncio.to_thread(ensure_connected)
    api_key = get_arena_api_key()
    api_base = get_api_base()
    mcp_url = get_mcp_url()
    proxy_host = get_proxy_host()
    http_client = HttpArenaClient(api_base=api_base, api_key=api_key)
    print("Registering with Agent Gauntlet...", flush=True)
    await asyncio.to_thread(http_client.register, agent_id, agent_name)
    print("Registered. Preparing for GO...", flush=True)

    async with monitor_session(http_client, agent_id):
        model_fetch = asyncio.create_task(
            asyncio.to_thread(fetch_available_models, proxy_host, api_key)
        )
        phase_latency_s = await _wait_for_running(http_client)
        available_models = await model_fetch
        usage_scope = await asyncio.to_thread(http_client.fetch_usage_scope) or resolve_usage_scope()
        async with McpArenaClient(mcp_url, api_key=api_key) as mcp_client:
            tool_defs = await mcp_client.list_tool_defs()
            tool_names = [tool.name for tool in tool_defs]
            print(f"Discovered {len(tool_defs)} MCP tools.", flush=True)
            server_remaining_s: float | None = None
            modality = await asyncio.to_thread(
                McpArenaClient.detect_modality,
                tool_names,
                agent_id=agent_id,
            )
            print(f"Assigned challenge modality: {modality}.", flush=True)
            if modality == "image":
                started = time.monotonic()
                challenge_image = await mcp_client.get_image_challenge(agent_id)
                challenge_latency_s = time.monotonic() - started
                challenge_type = challenge_image.challenge_type
                description = challenge_image.description
                rules = challenge_image.prompt
                max_time_s = challenge_image.max_time_s
                remaining_s = challenge_image.time_remaining_s
                required = frozenset(challenge_image.required_tools)
                clues: list[str] = []
                image_challenge: ImageChallengeInfo | None = challenge_image
                text_challenge: ChallengeInfo | None = None
                print_challenge(challenge_image)
            else:
                started = time.monotonic()
                challenge_text = await mcp_client.get_challenge(agent_id)
                challenge_latency_s = time.monotonic() - started
                challenge_type = challenge_text.challenge_type
                description = challenge_text.description
                rules = challenge_text.rules
                max_time_s = challenge_text.max_time_s
                remaining_s = challenge_text.time_remaining_s
                required = _required_tools(challenge_text.raw_data.get("required_tools"))
                print_challenge(challenge_text)
                print("Reading challenge clues...", flush=True)
                clues = await mcp_client.get_all_clue_texts(agent_id)
                if not clues:
                    clues = challenge_text.clues
                print(f"Loaded {len(clues)} clues.", flush=True)
                time_info = await mcp_client.time_remaining(agent_id)
                remaining_value = time_info.get("time_remaining_s")
                if isinstance(remaining_value, (int, float)) and remaining_value > 0:
                    server_remaining_s = float(remaining_value)
                image_challenge = None
                text_challenge = challenge_text

            if remaining_s <= 0:
                raise RuntimeError("Challenge response did not provide positive time_remaining_s")
            deadline = started + remaining_s
            if server_remaining_s is not None:
                deadline = min(deadline, time.monotonic() + server_remaining_s)
            submit_reserve_s = max(phase_latency_s, challenge_latency_s)
            selected_model, model_context = _select_model(
                strategy,
                challenge_type=challenge_type,
                description=description,
                rules=rules,
                max_time_s=max_time_s,
                available_models=available_models,
            )
            print(f"Selected model: {selected_model}", flush=True)
            llm_client = AsyncOpenAI(
                base_url=proxy_host,
                api_key=api_key,
                default_headers=build_proxy_headers(agent_id, usage_scope),
            )
            async with llm_client:
                if image_challenge is not None:
                    image_uri, metadata, result = await _run_image_challenge(
                        challenge=image_challenge,
                        tool_defs=tool_defs,
                        mcp_client=mcp_client,
                        http_client=http_client,
                        strategy=strategy,
                        model=selected_model,
                        agent_id=agent_id,
                        llm_api_key=api_key,
                        arena_api_key=api_key,
                        deadline=deadline,
                    )
                    print(f"Image submitted: {save_submitted_image(agent_id, image_uri, KIT_ROOT)}")
                    for line in submission_summary_lines(result):
                        print(line)
                    run_record = {
                        "agent_id": agent_id,
                        "challenge": challenge_record(image_challenge),
                        "model": selected_model,
                        "image_tool_sequence": metadata["tool_sequence"],
                        "result": result,
                    }
                    save_run_record(agent_id, run_record, KIT_ROOT)
                    return

                if text_challenge is None:
                    raise RuntimeError("Text challenge setup did not return challenge data")
                outcome_candidate, outcome, result = await _run_text_challenge(
                    challenge=text_challenge,
                    clues=clues,
                    required=required,
                    tool_defs=tool_defs,
                    mcp_client=mcp_client,
                    http_client=http_client,
                    llm_client=llm_client,
                    model=selected_model,
                    agent_id=agent_id,
                    model_context=model_context,
                    deadline=deadline,
                    submit_reserve_s=submit_reserve_s,
                    strategy=strategy,
                )
                if result is None:
                    missing = sorted(required - outcome.used_tool_names)
                    reason = "; missing required tools: " + ", ".join(missing) if missing else ""
                    print(f"No final submission ({outcome.stop_reason}){reason}.")
                    save_run_record(
                        agent_id,
                        {
                            "agent_id": agent_id,
                            "challenge": challenge_record(text_challenge),
                            "model": selected_model,
                            "answer": outcome_candidate,
                            "steps": outcome.steps,
                            "tool_names": sorted(outcome.used_tool_names),
                            "stop_reason": outcome.stop_reason,
                            "result": None,
                        },
                        KIT_ROOT,
                    )
                    return
                print(f"Answer submitted after {outcome.steps} ReAct turn(s): {outcome_candidate}")
                for line in submission_summary_lines(result):
                    print(line)
                missing = missing_tools_note(result)
                if missing:
                    print(missing)
                run_record = {
                    "agent_id": agent_id,
                    "challenge": challenge_record(text_challenge),
                    "model": selected_model,
                    "answer": outcome_candidate,
                    "steps": outcome.steps,
                    "tool_names": sorted(outcome.used_tool_names),
                    "usage": {
                        "prompt_tokens": outcome.prompt_tokens,
                        "completion_tokens": outcome.completion_tokens,
                        "total_tokens": outcome.total_tokens,
                    },
                    "elapsed_ms": outcome.elapsed_ms,
                    "stop_reason": outcome.stop_reason,
                    "result": result,
                }
                save_run_record(agent_id, run_record, KIT_ROOT)
