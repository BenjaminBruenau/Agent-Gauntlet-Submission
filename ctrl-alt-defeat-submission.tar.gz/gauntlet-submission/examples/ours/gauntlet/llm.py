"""Async streaming chat client for the Arena LLM proxy."""

import asyncio
from dataclasses import dataclass, field

import openai
from arena_clients.proxy_headers import build_proxy_headers
from openai import AsyncOpenAI
from openai.types.chat import ChatCompletionChunk
from pydantic import JsonValue

from .console import Console
from .schemas import ChatMessage, ToolCall, TurnResult

CHARS_PER_TOKEN = 4


class LlmError(Exception):
    """The proxy or provider rejected or dropped a request."""

    def __init__(self, model: str, message: str, status: int | None = None) -> None:
        super().__init__(f"{model}: {message}")
        self.model = model
        self.status = status

    @property
    def model_gone(self) -> bool:
        """The proxy says the model itself is unavailable (404 or 5xx), not that this caller was refused."""
        return self.status is not None and (self.status == 404 or self.status >= 500)


@dataclass
class UsageMeter:
    """Tokens this process has spent; estimated from text length when a stream reports none."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    estimated: bool = False

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens

    def add(self, turn: TurnResult) -> None:
        if turn.completion_tokens is None:
            chars = len(turn.content) + len(turn.reasoning) + sum(len(c.arguments) for c in turn.tool_calls)
            self.completion_tokens += chars // CHARS_PER_TOKEN
            self.estimated = True
        else:
            self.completion_tokens += turn.completion_tokens
        self.prompt_tokens += turn.prompt_tokens or 0


def ordered_calls(calls: dict[int, ToolCall]) -> list[ToolCall]:
    """Tool calls in stream order; a provider that sends no call id gets a positional one."""
    return [calls[index].model_copy(update={"id": calls[index].id or f"call_{index}"}) for index in sorted(calls)]


@dataclass
class _Accumulator:
    model: str
    content: list[str] = field(default_factory=list)
    reasoning: list[str] = field(default_factory=list)
    reasoning_details: list[JsonValue] = field(default_factory=list)
    calls: dict[int, ToolCall] = field(default_factory=dict)
    finish_reason: str = ""
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    first_delta_at: float | None = None

    def add(self, chunk: ChatCompletionChunk, now: float) -> tuple[str, str]:
        """Fold one chunk in; returns the (reasoning, answer) text it carried."""
        if chunk.usage is not None:
            self.prompt_tokens = chunk.usage.prompt_tokens
            self.completion_tokens = chunk.usage.completion_tokens
        if not chunk.choices:
            return "", ""
        choice = chunk.choices[0]
        if choice.finish_reason:
            self.finish_reason = choice.finish_reason
        delta = choice.delta
        # Providers disagree on the reasoning field name and it is not in the SDK's typed fields.
        reasoning = getattr(delta, "reasoning_content", None) or getattr(delta, "reasoning", None) or ""
        details = getattr(delta, "reasoning_details", None)
        content = delta.content or ""
        if details:
            self.reasoning_details.extend(details)
        for part in delta.tool_calls or []:
            call = self.calls.setdefault(part.index, ToolCall(id="", name="", arguments=""))
            call.id = part.id or call.id
            if part.function is not None:
                call.name += part.function.name or ""
                call.arguments += part.function.arguments or ""
        has_delta = bool(reasoning or content or delta.tool_calls or details)
        if has_delta and self.first_delta_at is None:
            self.first_delta_at = now
        if reasoning:
            self.reasoning.append(reasoning)
        if content:
            self.content.append(content)
        return reasoning, content


class LlmClient:
    def __init__(
        self,
        host: str,
        api_key: str,
        agent_id: str,
        usage_scope: str | None,
        console: Console,
        meter: UsageMeter,
    ) -> None:
        # Retries are ours to decide: the SDK's silent retries would burn the deadline.
        self._client = AsyncOpenAI(
            base_url=host,
            api_key=api_key,
            default_headers=build_proxy_headers(agent_id, usage_scope),
            max_retries=0,
        )
        self._agent_id = agent_id
        self._console = console
        self.meter = meter

    def set_usage_scope(self, usage_scope: str | None) -> None:
        """Attribute later calls to a new round; the scope can change at GO."""
        self._client = self._client.with_options(default_headers=build_proxy_headers(self._agent_id, usage_scope))

    async def stream_turn(
        self,
        model: str,
        messages: list[ChatMessage],
        tools: list[dict[str, JsonValue]],
        *,
        tool_choice: str | dict[str, JsonValue] = "auto",
        timeout_s: float,
        ttft_budget_s: float,
        reasoning_effort: str | None = None,
        live: bool = True,
    ) -> TurnResult:
        """Stream one completion. A cut stream (stalled or past ``timeout_s``) returns its partial text and no tool calls.

        ``live`` shows the reasoning ticker on the console; probes turn it off.
        """
        loop = asyncio.get_running_loop()
        started = loop.time()
        acc = _Accumulator(model)
        kwargs: dict[str, JsonValue] = {"stream_options": {"include_usage": True}}
        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = tool_choice
        if reasoning_effort:
            kwargs["extra_body"] = {"reasoning": {"effort": reasoning_effort}}
        try:
            async with asyncio.timeout(min(ttft_budget_s, timeout_s)) as limit:
                stream = await self._client.chat.completions.create(
                    model=model, messages=messages, stream=True, **kwargs
                )
                try:
                    async for chunk in stream:
                        first = acc.first_delta_at is None
                        reasoning, answer = acc.add(chunk, loop.time())
                        if first and acc.first_delta_at is not None:
                            limit.reschedule(started + timeout_s)
                        if (reasoning or answer) and live:
                            self._console.stream(model, reasoning, answer)
                finally:
                    await stream.close()
            cause = "complete"
        except TimeoutError:
            stalled = acc.first_delta_at is None and ttft_budget_s < timeout_s
            cause = "ttft_stall" if stalled else "deadline"
        except openai.APIError as exc:
            raise LlmError(model, str(exc), getattr(exc, "status_code", None)) from exc
        finally:
            if live:
                self._console.stream_end(model)
        turn = TurnResult(
            model=model,
            content="".join(acc.content),
            reasoning="".join(acc.reasoning),
            reasoning_details=acc.reasoning_details,
            tool_calls=ordered_calls(acc.calls) if cause == "complete" else [],
            finish_reason=acc.finish_reason,
            cause=cause,
            prompt_tokens=acc.prompt_tokens,
            completion_tokens=acc.completion_tokens,
            ttft_s=None if acc.first_delta_at is None else acc.first_delta_at - started,
            duration_s=loop.time() - started,
        )
        self.meter.add(turn)
        return turn
