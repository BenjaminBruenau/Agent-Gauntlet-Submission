"""Monotonic deadline anchored to the server's remaining time, plus timing constants."""

import time

from pydantic import BaseModel

from .schemas import Challenge


class Timing(BaseModel, frozen=True):
    """Provisional values; calibrate them from the trace (submit RTT, TTFT, turn time)."""

    # Seconds kept free for the submit round trip; the watchdog fires at this point.
    submit_reserve_s: float = 3.0
    # Below this the loop stops exploring and forces one final_answer turn.
    force_final_s: float = 12.0
    # A stream without any delta after this long counts as a stalled model.
    ttft_budget_s: float = 20.0
    max_steps: int = 8
    max_verify_rounds: int = 2
    max_model_switches: int = 2
    max_image_redos: int = 2
    # A verify or redo round must fit this many times the last comparable round.
    round_margin: float = 1.2
    phase_poll_s: float = 0.25
    status_interval_s: float = 1.0
    broadcast_excerpt_chars: int = 400
    tool_result_max_chars: int = 8000
    # Text models the light lobby probe pings, best-ranked first.
    probe_models: int = 4
    # Used only to estimate a model's turn time from catalog latency and throughput.
    expected_turn_tokens: int = 600
    # A model is skipped when this many estimated turns exceed budget_share of the time left.
    budgeted_turns: int = 3
    budget_share: float = 0.6
    challenge_lock_retry_s: float = 10.0
    probe_timeout_s: float = 15.0


class Deadline:
    """Time left in the heat. Never grants a fresh ``max_time_s`` at request time."""

    def __init__(self, ends_at: float, total_s: float) -> None:
        self.ends_at = ends_at
        self.total_s = total_s

    @classmethod
    def from_challenge(cls, request_sent_at: float, challenge: Challenge) -> "Deadline":
        """Anchor at the moment the challenge request left, which is never later than GO plus RTT."""
        remaining = challenge.time_remaining_s or challenge.max_time_s
        if remaining <= 0:
            raise ValueError("challenge reports no time limit (time_remaining_s and max_time_s are 0)")
        return cls(request_sent_at + remaining, challenge.max_time_s or remaining)

    def left(self) -> float:
        return self.ends_at - time.monotonic()

    def elapsed(self) -> float:
        return self.total_s - self.left()
