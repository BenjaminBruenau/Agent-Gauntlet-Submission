"""Runtime tool discovery: model-facing tool schemas, automatic arguments, artifact handles, call log."""

import asyncio
import copy
import json
import re
import time
from collections.abc import Iterable

from arena_clients.mcp_client import McpArenaClient, ToolOutcome
from mcp.shared.exceptions import McpError
from mcp.types import Tool
from pydantic import BaseModel, JsonValue

from .clock import Timing
from .console import Console, one_line
from .contract import (
    AGENT_ID,
    FINAL_ANSWER,
    HARNESS_OWNED,
    IMAGE_MODEL_TOOLS,
    MODEL,
    PROXY_API_KEY,
    THINK,
    Role,
)
from .schemas import ToolCallRecord, ToolResult

HANDLE = re.compile(r"artifact://(\d+)")
BASE64_ONLY = re.compile(r"^[A-Za-z0-9+/]+={0,2}$")
MIN_DATA_URI_CHARS = 256
MIN_BASE64_CHARS = 2000
ILLEGAL_NAME_CHARS = re.compile(r"[^A-Za-z0-9_-]")
MAX_NAME_CHARS = 64
FREE_FORM_SCHEMA: dict[str, JsonValue] = {"type": "object", "additionalProperties": True}


class ArtifactStore:
    """Keeps large payloads (images) out of the model's context behind short handles."""

    def __init__(self) -> None:
        self._by_handle: dict[str, str] = {}
        self._by_value: dict[str, str] = {}

    def add(self, value: str) -> str:
        if value not in self._by_value:
            handle = f"artifact://{len(self._by_handle) + 1}"
            self._by_handle[handle] = value
            self._by_value[value] = handle
        return self._by_value[value]

    def shrink(self, value: JsonValue) -> JsonValue:
        if isinstance(value, str):
            is_data_uri = value.startswith("data:") and len(value) >= MIN_DATA_URI_CHARS
            is_base64 = len(value) >= MIN_BASE64_CHARS and BASE64_ONLY.match(value) is not None
            return self.add(value) if is_data_uri or is_base64 else value
        if isinstance(value, list):
            return [self.shrink(item) for item in value]
        if isinstance(value, dict):
            return {key: self.shrink(item) for key, item in value.items()}
        return value

    def expand_text(self, text: str) -> str:
        return HANDLE.sub(lambda match: self._by_handle.get(match.group(0), match.group(0)), text)

    def expand(self, value: JsonValue) -> JsonValue:
        if isinstance(value, str):
            return self.expand_text(value)
        if isinstance(value, list):
            return [self.expand(item) for item in value]
        if isinstance(value, dict):
            return {key: self.expand(item) for key, item in value.items()}
        return value


class ToolSpec(BaseModel, frozen=True):
    name: str
    model_name: str
    description: str
    parameters: dict[str, JsonValue]
    declared: frozenset[str]
    required: tuple[str, ...]
    listed_only: bool = False


def model_name_for(name: str, taken: set[str]) -> str:
    """A provider-legal function name for an MCP tool name, unique among ``taken``."""
    base = ILLEGAL_NAME_CHARS.sub("_", name)[:MAX_NAME_CHARS]
    candidate, suffix = base, 1
    while candidate in taken:
        suffix += 1
        tail = f"_{suffix}"
        candidate = base[: MAX_NAME_CHARS - len(tail)] + tail
    return candidate


def outcome_error(outcome: ToolOutcome) -> str:
    data = outcome.data
    if "error" in data:
        return str(data["error"])
    if outcome.is_error:
        return " ".join(outcome.texts) or "tool reported an error"
    return ""


class ToolRegistry:
    def __init__(
        self,
        mcp: McpArenaClient,
        *,
        agent_id: str,
        image_model: str,
        timing: Timing,
        console: Console,
        artifacts: ArtifactStore,
    ) -> None:
        self._mcp = mcp
        self._agent_id = agent_id
        self.image_model = image_model
        self._timing = timing
        self._console = console
        self.artifacts = artifacts
        self._specs: dict[str, ToolSpec] = {}
        self.records: list[ToolCallRecord] = []
        self._started = time.monotonic()

    @property
    def names(self) -> set[str]:
        return set(self._specs)

    def has(self, role: Role) -> bool:
        return role.value in self._specs

    def load(self, defs: list[Tool], listed_names: Iterable[str] = ()) -> None:
        """Replace the known tools with MCP definitions plus names that only ``arena.tools.list`` reports."""
        specs: dict[str, ToolSpec] = {}
        taken: set[str] = {FINAL_ANSWER, THINK}
        for tool in defs:
            spec = self._spec_from_def(tool, model_name_for(tool.name, taken))
            taken.add(spec.model_name)
            specs[spec.name] = spec
        for name in listed_names:
            if name not in specs:
                model_name = model_name_for(name, taken)
                taken.add(model_name)
                specs[name] = ToolSpec(
                    name=name,
                    model_name=model_name,
                    description="Published without a schema; arguments are passed through unchanged.",
                    parameters=FREE_FORM_SCHEMA,
                    declared=frozenset(),
                    required=(),
                    listed_only=True,
                )
        self._specs = specs

    def model_tools(self) -> list[dict[str, JsonValue]]:
        """OpenAI tool definitions for every discovered tool the harness does not own."""
        return [
            {
                "type": "function",
                "function": {
                    "name": spec.model_name,
                    "description": spec.description,
                    "parameters": spec.parameters,
                },
            }
            for spec in self._specs.values()
            if spec.name not in HARNESS_OWNED
        ]

    def spec_for_model_name(self, model_name: str) -> ToolSpec | None:
        return next((spec for spec in self._specs.values() if spec.model_name == model_name), None)

    def called_ok(self) -> set[str]:
        return {record.name for record in self.records if record.ok}

    def missing_required(self, required: list[str]) -> list[str]:
        done = self.called_ok()
        return [name for name in required if name not in done]

    def is_auto_callable(self, name: str) -> bool:
        spec = self._specs.get(name)
        return spec is not None and not spec.required

    def accepts(self, name: str, argument: str) -> bool:
        """Whether the tool's schema declares ``argument`` (including ones hidden from the model)."""
        spec = self._specs.get(name)
        return spec is not None and argument in spec.declared

    async def call(
        self,
        name: str,
        arguments: dict[str, JsonValue],
        *,
        timeout_s: float | None = None,
        quiet: bool = False,
    ) -> ToolResult:
        spec = self._specs.get(name)
        if spec is None:
            return ToolResult(error=f"tool {name} was not discovered")
        args = {key: value for key, value in arguments.items() if key != PROXY_API_KEY}
        if AGENT_ID in spec.declared or spec.listed_only:
            args[AGENT_ID] = self._agent_id
        if name in IMAGE_MODEL_TOOLS and MODEL in spec.declared and self.image_model:
            args.setdefault(MODEL, self.image_model)
        args = self.artifacts.expand(args)
        started = time.monotonic()
        missing = [key for key in spec.required if key not in args]
        if missing:
            result = ToolResult(error=f"missing required arguments: {', '.join(missing)}")
        else:
            result = await self._invoke(name, args, timeout_s)
        duration = time.monotonic() - started
        preview = one_line(result.error or json.dumps(self.artifacts.shrink(result.data), default=str))
        self.records.append(
            ToolCallRecord(
                name=name,
                arguments=self.artifacts.shrink(args),
                ok=result.ok,
                started_s=started - self._started,
                duration_s=duration,
                preview=preview,
            )
        )
        flag = "🔧" if result.ok else "⚠️ "
        emit = self._console.trace if quiet else self._console.log
        emit(
            "tool",
            f"{flag} {name}({one_line(json.dumps(self.artifacts.shrink(args), default=str), 160)})"
            f" {duration:.1f}s → {preview}",
            name=name,
            ok=result.ok,
            arguments=self.artifacts.shrink(args),
            result=result.error or self.artifacts.shrink(result.data),
        )
        return result

    def render(self, result: ToolResult) -> str:
        """The text a model sees for a result: JSON with large payloads replaced by handles."""
        if result.error:
            return f"ERROR: {result.error}"
        payload: dict[str, JsonValue] = {"result": self.artifacts.shrink(result.data)}
        if result.images:
            payload["images"] = [self.artifacts.add(uri) for uri in result.images]
        text = json.dumps(payload, ensure_ascii=False, default=str)
        limit = self._timing.tool_result_max_chars
        if len(text) > limit:
            return f"{text[:limit]}… [truncated {len(text) - limit} chars]"
        return text

    async def _invoke(self, name: str, args: dict[str, JsonValue], timeout_s: float | None) -> ToolResult:
        try:
            async with asyncio.timeout(timeout_s):
                outcome = await self._mcp.call_tool_outcome(name, args)
        except TimeoutError:
            return ToolResult(error=f"timed out after {timeout_s:.0f}s")
        except McpError as exc:
            return ToolResult(error=f"MCP error: {exc}")
        return ToolResult(data=outcome.data, images=outcome.images, error=outcome_error(outcome))

    @staticmethod
    def _spec_from_def(tool: Tool, model_name: str) -> ToolSpec:
        parameters = copy.deepcopy(tool.inputSchema)
        properties = parameters.setdefault("properties", {})
        declared = frozenset(properties)
        hidden = {AGENT_ID, PROXY_API_KEY}
        if tool.name in IMAGE_MODEL_TOOLS:
            hidden.add(MODEL)
        for key in hidden:
            properties.pop(key, None)
        required = tuple(key for key in parameters.get("required", []) if key not in hidden)
        if required:
            parameters["required"] = list(required)
        else:
            parameters.pop("required", None)
        return ToolSpec(
            name=tool.name,
            model_name=model_name,
            description=tool.description or tool.name,
            parameters=parameters,
            declared=declared,
            required=required,
        )
