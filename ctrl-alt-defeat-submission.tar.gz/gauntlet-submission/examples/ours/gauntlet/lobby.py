"""Lobby: watch the competition phase until GO."""

from __future__ import annotations

import asyncio

from arena_clients import ArenaAPIError, ArenaConnectionError, HttpArenaClient
from model_selector import fetch_available_model_rows
from pydantic import JsonValue

from .clock import Timing
from .console import Console

GO_PHASE = "running"
LOBBY_PHASE = "lobby"
ROSTER_RETRY_S = 1.0


async def discover_roster(proxy_host: str, api_key: str, console: Console) -> list[dict[str, JsonValue]]:
    """The proxy's model rows; keeps asking until it answers, because nothing can be solved without a model."""
    while True:
        rows = await asyncio.to_thread(fetch_available_model_rows, proxy_host, api_key)
        if rows:
            return rows
        console.log("lobby", "⚠️  the proxy returned no models; retrying")
        await asyncio.sleep(ROSTER_RETRY_S)


async def current_phase(http: HttpArenaClient) -> str:
    competition = await asyncio.to_thread(http.get_competition)
    return str(competition.get("phase") or "").strip().lower()


async def wait_for_go(http: HttpArenaClient, console: Console, timing: Timing, probe: asyncio.Task[None] | None) -> None:
    """Poll the phase until it is ``running``. The probe is cancelled the moment the phase leaves ``lobby``,
    because proxy calls from the countdown onward count against the round."""
    last = ""
    while True:
        try:
            phase = await current_phase(http)
        except (ArenaAPIError, ArenaConnectionError) as exc:
            console.log("phase", f"⚠️  phase poll failed: {exc}")
            await asyncio.sleep(timing.phase_poll_s)
            continue
        if phase != last:
            console.log("phase", f"🚦 phase: {phase or '(unknown)'}", phase=phase)
            last = phase
        if phase != LOBBY_PHASE and probe is not None and not probe.done():
            probe.cancel()
        if phase == GO_PHASE:
            return
        await asyncio.sleep(timing.phase_poll_s)
