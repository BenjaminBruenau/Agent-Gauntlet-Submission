"""Runtime settings read once from the environment."""

import os
import tempfile
from pathlib import Path

from arena_clients.config import (
    agent_id_problem,
    get_api_base,
    get_arena_api_key,
    get_mcp_url,
    get_proxy_host,
)
from my_strategy import MyStrategy
from pydantic import BaseModel

FALSE_WORDS = {"0", "off", "false", "no"}


def _flag(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    return raw.strip().lower() not in FALSE_WORDS


class Settings(BaseModel, frozen=True):
    agent_id: str
    agent_name: str
    api_base: str
    mcp_url: str
    proxy_host: str
    api_key: str
    # Code directories are read-only in the sandbox, so the default is the temp dir.
    output_dir: Path
    # Force one model for every text / image call (benchmarks, ablations).
    text_model: str = ""
    image_model: str = ""
    think_tool: bool = False
    verify: bool = True
    lobby_probe: bool = True

    @classmethod
    def from_env(cls) -> "Settings":
        strategy = MyStrategy()
        agent_id = (os.getenv("AGENT_ID") or strategy.agent_id).strip()
        problem = agent_id_problem(agent_id)
        if problem:
            raise SystemExit(f"❌ {problem}")
        output_dir = os.getenv("AGENT_OUTPUT_DIR") or str(
            Path(tempfile.gettempdir()) / f"gauntlet-{agent_id}"
        )
        return cls(
            agent_id=agent_id,
            agent_name=(os.getenv("AGENT_NAME") or strategy.agent_name).strip(),
            api_base=get_api_base(),
            mcp_url=get_mcp_url(),
            proxy_host=get_proxy_host(),
            api_key=get_arena_api_key(),
            output_dir=Path(output_dir),
            text_model=os.getenv("AGENT_TEXT_MODEL", "").strip(),
            image_model=os.getenv("AGENT_IMAGE_MODEL", "").strip(),
            think_tool=_flag("GAUNTLET_THINK_TOOL", False),
            verify=_flag("GAUNTLET_VERIFY", True),
            lobby_probe=_flag("GAUNTLET_LOBBY_PROBE", True),
        )
