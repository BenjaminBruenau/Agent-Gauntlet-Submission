"""The only place the starter-kit's tool names appear. A role is used only when discovery reports it."""

from enum import StrEnum


class Role(StrEnum):
    GET_CHALLENGE = "arena.get_challenge"
    IMAGE_GET_CHALLENGE = "arena.image.get_challenge"
    CLUES_LIST = "arena.clues.list"
    CLUES_GET = "arena.clues.get"
    TIME_REMAINING = "arena.time_remaining"
    TOOLS_LIST = "arena.tools.list"
    IMAGE_BROADCAST = "arena.image.broadcast_thought"
    IMAGE_SUBMIT = "arena.image.submit_edit"
    IMAGE_EDIT = "image_edit"
    IMAGE_GENERATE = "image_generate"
    IMAGE_ANALYZE = "image_analyze"


# Lifecycle tools the harness calls itself; the model never sees them.
HARNESS_OWNED = frozenset(
    {
        Role.GET_CHALLENGE,
        Role.IMAGE_GET_CHALLENGE,
        Role.CLUES_LIST,
        Role.CLUES_GET,
        Role.TIME_REMAINING,
        Role.TOOLS_LIST,
        Role.IMAGE_BROADCAST,
        Role.IMAGE_SUBMIT,
    }
)

# Image tools that take an optional image model alias.
IMAGE_MODEL_TOOLS = frozenset({Role.IMAGE_EDIT, Role.IMAGE_GENERATE, Role.IMAGE_ANALYZE})

# Argument and result keys of the image tools.
IMAGE_URI = "image_uri"
PROMPT = "prompt"
QUESTION = "question"
ANALYSIS_TEXT = "text"

AGENT_ID = "agent_id"
# Credential argument: never shown to the model, never filled (the proxy key equals the arena key).
PROXY_API_KEY = "proxy_api_key"
MODEL = "model"

# Tools the harness itself adds for the model; discovered tools may not reuse these names.
FINAL_ANSWER = "final_answer"
THINK = "think"


def challenge_tool(modality: str, discovered: set[str]) -> str:
    """The get-challenge tool for a modality: ``arena.<modality>.get_challenge`` if discovered, else the generic one."""
    specific = f"arena.{modality}.get_challenge"
    return specific if specific in discovered else Role.GET_CHALLENGE.value
