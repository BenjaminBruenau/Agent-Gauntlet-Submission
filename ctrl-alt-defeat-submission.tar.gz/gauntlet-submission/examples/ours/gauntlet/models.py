"""Model ranking: hardcoded Practice order, else packaged OpenRouter catalog scores, else a name heuristic."""

from __future__ import annotations

import json
import re
from collections.abc import Callable
from pathlib import Path

from model_selector import prefer_image_models, require_explicit_model
from pydantic import BaseModel, JsonValue

from .clock import Timing
from .schemas import ProbeResult

CATALOG_PATH = Path(__file__).with_name("model_catalog.json")

# Seed order from catalog intelligence scores; replaced by our own benchmark results.
PRACTICE_TEXT_RANKING = (
    "gpt-5.6-terra",
    "gpt-5.4",
    "gemini-3.8-flash",
    "qwen3.7-max",
    "qwen3.7-plus",
    "qwen3.7-flash",
    "nemotron-3-ultra",
    "gemini-3.6-flash",
    "qwen3.6-35b",
    "nemotron-3-super",
    "nemotron-3.5-lightning",
)
# gemini-3-pro-image is the older generation; lite has no benchmark score.
PRACTICE_IMAGE_RANKING = (
    "gemini-3.1-flash-image",
    "gemini-3-pro-image",
    "gemini-3.1-flash-lite-image",
)
PRACTICE_ROSTER = frozenset(PRACTICE_TEXT_RANKING + PRACTICE_IMAGE_RANKING)

# Weak cross-vendor evidence, used only for models the catalog does not know.
TIERS = {
    "ultra": 3, "max": 3, "pro": 3, "opus": 3,
    "plus": 2, "super": 2, "sonnet": 2,
    "flash": 1, "mini": 1, "haiku": 1, "lightning": 1,
    "lite": 0, "nano": 0, "small": 0,
}  # fmt: skip
VERSION = re.compile(r"\d+(?:\.\d+)*")


class CatalogEntry(BaseModel):
    slug: str
    input_modalities: list[str]
    output_modalities: list[str]
    tools: bool
    p50_latency_ms: float | None = None
    p50_throughput: float | None = None
    edit_score: float | None = None
    generate_score: float | None = None
    intelligence: float | None = None
    agentic: float | None = None
    coding: float | None = None

    @property
    def tail(self) -> str:
        return self.slug.rsplit("/", 1)[-1]


class Catalog:
    def __init__(self, entries: list[CatalogEntry]) -> None:
        self._by_tail: dict[str, list[CatalogEntry]] = {}
        for entry in entries:
            self._by_tail.setdefault(entry.tail, []).append(entry)

    @classmethod
    def load(cls) -> "Catalog":
        raw = json.loads(CATALOG_PATH.read_text(encoding="utf-8"))
        return cls([CatalogEntry.model_validate(item) for item in raw["models"]])

    def lookup(self, alias: str) -> CatalogEntry | None:
        """The entry for a proxy alias: exact name, else the single name extending it (``nemotron-3-ultra`` -> ``...-550b-a55b``).

        An OpenRouter ``-preview`` sibling contributes the benchmark scores the final model lacks.
        """
        matches = list(self._by_tail.get(alias, []))
        if not matches:
            extended = [tail for tail in self._by_tail if tail.startswith(alias + "-") and not tail.endswith("-preview")]
            if len(extended) == 1:
                matches = list(self._by_tail[extended[0]])
        matches += self._by_tail.get(alias + "-preview", [])
        if not matches:
            return None
        merged = matches[0].model_dump()
        for entry in matches[1:]:
            for key, value in entry.model_dump().items():
                if merged[key] in (None, [], False):
                    merged[key] = value
        return CatalogEntry.model_validate(merged)


def heuristic_key(alias: str) -> tuple[int, tuple[int, ...]]:
    tier = max((rank for word, rank in TIERS.items() if word in alias.split("-")), default=1)
    match = VERSION.search(alias)
    version = tuple(int(part) for part in match.group(0).split(".")) if match else ()
    return tier, version


class ModelBook:
    """Ranked text and image models for this heat, adjusted by probe results and the time left."""

    def __init__(
        self,
        roster: list[str],
        rows: list[dict[str, JsonValue]],
        catalog: Catalog,
        *,
        forced_text: str = "",
        forced_image: str = "",
    ) -> None:
        self._catalog = catalog
        self.probes: dict[str, ProbeResult] = {}
        image = prefer_image_models(roster, model_rows=rows)
        text = [alias for alias in roster if alias not in image]
        self.source = "practice" if set(roster) == PRACTICE_ROSTER else "catalog"
        if self.source == "practice":
            self._text, self._image = list(PRACTICE_TEXT_RANKING), list(PRACTICE_IMAGE_RANKING)
        else:
            self._text = self._rank(text, lambda entry: entry.intelligence)
            self._image = image
        if forced_text:
            self._text = [require_explicit_model(forced_text, roster, source="AGENT_TEXT_MODEL")]
        if forced_image:
            self._image = [require_explicit_model(forced_image, roster, source="AGENT_IMAGE_MODEL")]

    def _rank(self, aliases: list[str], score: Callable[[CatalogEntry], float | None]) -> list[str]:
        scored: list[tuple[float, str]] = []
        unscored: list[str] = []
        for alias in aliases:
            entry = self._catalog.lookup(alias)
            value = None if entry is None else score(entry)
            if value is None:
                unscored.append(alias)
            else:
                scored.append((value, alias))
        scored.sort(key=lambda item: item[0], reverse=True)
        unscored.sort(key=heuristic_key, reverse=True)
        return [alias for _, alias in scored] + unscored

    @property
    def ranked_text(self) -> list[str]:
        return list(self._text)

    def apply_probes(self, results: list[ProbeResult]) -> None:
        self.probes.update({result.model: result for result in results})

    def eligible(self, alias: str) -> bool:
        """False once a probe or the catalog shows the model cannot take part in a tool-calling loop."""
        probe = self.probes.get(alias)
        if probe is not None and (not probe.available or probe.tool_calls_ok is False):
            return False
        entry = self._catalog.lookup(alias)
        return entry is None or entry.tools

    def estimate_turn_s(self, alias: str, timing: Timing) -> float | None:
        entry = self._catalog.lookup(alias)
        probe = self.probes.get(alias)
        latency = probe.ttft_s if probe is not None and probe.ttft_s is not None else None
        if latency is None and entry is not None and entry.p50_latency_ms is not None:
            latency = entry.p50_latency_ms / 1000
        if latency is None or entry is None or not entry.p50_throughput:
            return None
        return latency + timing.expected_turn_tokens / entry.p50_throughput

    def text_candidates(self, left_s: float, timing: Timing) -> list[str]:
        """Eligible models in rank order, minus those too slow for the turns budgeted in the time left."""
        eligible = [alias for alias in self._text if self.eligible(alias)]
        budget = timing.budget_share * left_s
        fits = [
            alias
            for alias in eligible
            if (estimate := self.estimate_turn_s(alias, timing)) is None or timing.budgeted_turns * estimate <= budget
        ]
        if fits or not eligible:
            return fits
        return [min(eligible, key=lambda alias: self.estimate_turn_s(alias, timing) or float("inf"))]

    def image_candidates(self, *, editing: bool) -> list[str]:
        if self.source == "practice":
            return list(self._image)
        return self._rank(self._image, lambda entry: entry.edit_score if editing else entry.generate_score)

    def vision_model(self) -> str | None:
        """The best-ranked text model that accepts images, if the catalog knows of one."""
        for alias in self._text:
            entry = self._catalog.lookup(alias)
            if self.eligible(alias) and entry is not None and "image" in entry.input_modalities:
                return alias
        return None

    def describe(self) -> str:
        return f"text [{self.source}]: {', '.join(self._text)} | image: {', '.join(self._image)}"
