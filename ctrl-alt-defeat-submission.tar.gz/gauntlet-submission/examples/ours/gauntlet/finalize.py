"""Exactly-once submission: the best-candidate slot, retries with an identical payload, and the deadline watchdog."""

import asyncio
import dataclasses
from collections.abc import Awaitable, Callable

import anyio
from arena_clients import ArenaConnectionError, HttpArenaClient, McpArenaClient
from mcp.shared.exceptions import McpError

from .clock import Deadline, Timing
from .console import Console, one_line
from .schemas import Candidate, Receipt
from .telemetry import Broadcaster, StatusReporter

Submitter = Callable[[Candidate], Awaitable[Receipt]]
SUBMIT_ATTEMPTS = 3
SUBMIT_RETRY_DELAY_S = 0.3
MCP_TRANSPORT_ERRORS = (anyio.ClosedResourceError, anyio.BrokenResourceError, McpError)


def text_submitter(
    http: HttpArenaClient,
    agent_id: str,
    status: StatusReporter,
    challenge_type: str | None,
) -> Submitter:
    """Submit over REST. ``challenge_type`` is None for text so the server uses the assignment."""

    async def submit(candidate: Candidate) -> Receipt:
        result = await asyncio.to_thread(
            http.submit, agent_id, candidate.answer, status.client_metrics(), challenge_type
        )
        return Receipt.model_validate(dataclasses.asdict(result))

    return submit


def image_submitter(
    mcp: McpArenaClient,
    http: HttpArenaClient,
    agent_id: str,
    status: StatusReporter,
    console: Console,
) -> Submitter:
    """Submit through the image tool; a dead MCP session falls back to REST with ``challenge_type="image"``."""

    async def submit(candidate: Candidate) -> Receipt:
        try:
            raw = await mcp.submit_image(agent_id, candidate.answer, status.client_metrics(), candidate.rationale)
        except MCP_TRANSPORT_ERRORS as exc:
            console.log("submit", f"⚠️  MCP session unavailable ({one_line(str(exc), 100)}); submitting over REST")
            result = await asyncio.to_thread(
                http.submit, agent_id, candidate.answer, status.client_metrics(), "image"
            )
            return Receipt.model_validate(dataclasses.asdict(result))
        return Receipt.model_validate(raw)

    return submit


class Finalizer:
    """Holds the best candidate and submits it exactly once."""

    def __init__(
        self,
        submit: Submitter,
        broadcaster: Broadcaster,
        console: Console,
        timing: Timing,
    ) -> None:
        self._submit = submit
        self._broadcaster = broadcaster
        self._console = console
        self._timing = timing
        self._lock = asyncio.Lock()
        self.candidate: Candidate | None = None
        self.receipt: Receipt | None = None

    def offer(self, candidate: Candidate) -> None:
        self.candidate = candidate
        self._console.log(
            "candidate",
            f"📝 Candidate ({candidate.source}): {one_line(candidate.display, 160)}"
            + (f" — {one_line(candidate.rationale, 240)}" if candidate.rationale else ""),
            source=candidate.source,
            answer=candidate.display,
            rationale=candidate.rationale,
        )

    async def submit_once(self) -> Receipt | None:
        async with self._lock:
            if self.receipt is not None:
                return self.receipt
            if self.candidate is None:
                self._console.log("submit", "⚠️  no candidate to submit")
                return None
            await self._broadcaster.ensure_min(1, self._timing.submit_reserve_s / 2)
            self._console.log("submit", f"📤 Submitting: {one_line(self.candidate.display, 160)}")
            self.receipt = await self._send(self.candidate)
            return self.receipt

    async def _send(self, candidate: Candidate) -> Receipt:
        """A lost response is retried with the identical payload; the server returns its stored receipt."""
        for attempt in range(1, SUBMIT_ATTEMPTS):
            try:
                return await self._submit(candidate)
            except ArenaConnectionError as exc:
                self._console.log("submit", f"⚠️  submit attempt {attempt} failed ({exc}); retrying with the same payload")
                await asyncio.sleep(SUBMIT_RETRY_DELAY_S)
        return await self._submit(candidate)


async def solve_then_submit(
    solve: Awaitable[None],
    deadline: Deadline,
    timing: Timing,
    finalizer: Finalizer,
    console: Console,
) -> Receipt | None:
    """Run ``solve``; when the submit reserve is reached, cancel it and submit the best candidate so far."""
    task = asyncio.ensure_future(solve)
    try:
        await asyncio.wait({task}, timeout=max(0.0, deadline.left() - timing.submit_reserve_s))
        if not task.done():
            console.log("watchdog", f"⏰ {deadline.left():.1f}s left: cancelling the solver and submitting the best candidate")
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)
    finally:
        if not task.done():
            task.cancel()
    failure = None if task.cancelled() else task.exception()
    receipt = await finalizer.submit_once()
    if failure is not None:
        raise failure
    return receipt
