"""After GO: fetch the challenge, then everything that depends on it in parallel."""

import asyncio
import re
import time
from dataclasses import dataclass

from arena_clients import McpArenaClient
from pydantic import JsonValue

from .clock import Deadline
from .context import RunContext
from .contract import Role, challenge_tool
from .schemas import Challenge, ToolResult

LOCKED = re.compile(r"locked|waiting for organizer", re.IGNORECASE)
WRONG_MODALITY = re.compile(r"not an? (?:image|text) challenge|not_(?:image|text)_challenge", re.IGNORECASE)


@dataclass(frozen=True)
class Boot:
    challenge: Challenge
    clues: list[str]
    deadline: Deadline


def tool_names(data: dict[str, JsonValue]) -> list[str]:
    """Names from an ``arena.tools.list`` reply, which may list plain names or objects with a ``name``."""
    tools = data.get("tools")
    if not isinstance(tools, list):
        return []
    return [item if isinstance(item, str) else str(item.get("name", "")) for item in tools if item]


async def _fetch_challenge(ctx: RunContext) -> tuple[ToolResult, float]:
    """Call the get-challenge tool, waiting out a lobby lock and correcting a stale modality once."""
    give_up = time.monotonic() + ctx.timing.challenge_lock_retry_s
    corrected = False
    while True:
        tool = challenge_tool(ctx.modality, ctx.registry.names)
        sent_at = time.monotonic()
        result = await ctx.registry.call(tool, {})
        if result.ok:
            return result, sent_at
        if LOCKED.search(result.error) and time.monotonic() < give_up:
            await asyncio.sleep(ctx.timing.phase_poll_s)
        elif WRONG_MODALITY.search(result.error) and not corrected:
            corrected = True
            ctx.modality = await asyncio.to_thread(
                McpArenaClient.detect_modality, sorted(ctx.registry.names), ctx.settings.agent_id
            )
            ctx.console.log("phase", f"🔁 assignment is a {ctx.modality} challenge")
        else:
            raise RuntimeError(f"{tool} failed: {result.error}")


async def _refresh_tools(ctx: RunContext) -> None:
    """Re-read the tool schemas and ``arena.tools.list``: the tool set can change at GO."""
    defs = await ctx.mcp.list_tool_defs()
    listed: list[str] = []
    if ctx.registry.has(Role.TOOLS_LIST):
        result = await ctx.registry.call(Role.TOOLS_LIST.value, {})
        listed = tool_names(result.data)
    ctx.registry.load(defs, listed)


async def _fetch_clues(ctx: RunContext, challenge: Challenge) -> list[str]:
    # Image assignments have no clue tools: the server answers clues.list with an error for them.
    if ctx.modality == "image" or not ctx.registry.has(Role.CLUES_LIST):
        return challenge.clues
    listing = await ctx.registry.call(Role.CLUES_LIST.value, {})
    if not listing.ok:
        raise RuntimeError(f"{Role.CLUES_LIST} failed: {listing.error}")
    ids = [str(clue_id) for clue_id in listing.data.get("clue_ids", [])]
    results = await asyncio.gather(*(ctx.registry.call(Role.CLUES_GET.value, {"clue_id": clue_id}) for clue_id in ids))
    clues: list[str] = []
    for clue_id, result in zip(ids, results):
        if not result.ok:
            raise RuntimeError(f"{Role.CLUES_GET} {clue_id} failed: {result.error}")
        clues.append(str(result.data.get("text", "")).strip())
    return [clue for clue in clues if clue] or challenge.clues


async def call_auto_required(ctx: RunContext, challenge: Challenge) -> list[str]:
    """Call required tools that need no arguments of ours; returns the required tools still uncalled."""
    pending = [name for name in ctx.registry.missing_required(challenge.required_tools) if ctx.registry.is_auto_callable(name)]
    await asyncio.gather(*(ctx.registry.call(name, {}) for name in pending))
    return ctx.registry.missing_required(challenge.required_tools)


async def bootstrap(ctx: RunContext) -> Boot:
    result, sent_at = await _fetch_challenge(ctx)
    challenge = Challenge.model_validate(result.data)
    deadline = Deadline.from_challenge(sent_at, challenge)
    async with asyncio.TaskGroup() as group:
        group.create_task(_refresh_tools(ctx))
        clues_task = group.create_task(_fetch_clues(ctx, challenge))
    await call_auto_required(ctx, challenge)
    return Boot(challenge=challenge, clues=clues_task.result(), deadline=deadline)
