"""The shared handles every stage of a run needs."""

from dataclasses import dataclass

from arena_clients import HttpArenaClient, McpArenaClient

from .clock import Timing
from .console import Console
from .llm import LlmClient
from .mcp_tools import ToolRegistry
from .models import ModelBook
from .settings import Settings
from .telemetry import Broadcaster, StatusReporter


@dataclass
class RunContext:
    settings: Settings
    timing: Timing
    console: Console
    http: HttpArenaClient
    mcp: McpArenaClient
    registry: ToolRegistry
    llm: LlmClient
    models: ModelBook
    broadcaster: Broadcaster
    status: StatusReporter
    # "text" or "image"; confirmed again after GO, because the lobby lookup can be stale.
    modality: str = "text"
