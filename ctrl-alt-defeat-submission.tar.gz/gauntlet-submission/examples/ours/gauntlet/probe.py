"""Model probes: a light lobby availability check and a full capability report (``python -m gauntlet.probe``)."""

import asyncio
import base64
import json
import struct
import zlib

from pydantic import BaseModel, Field, JsonValue

from .clock import Timing
from .console import Console
from .llm import LlmClient, LlmError, UsageMeter
from .models import Catalog, ModelBook
from .schemas import ChatMessage, ProbeResult, TurnResult
from .settings import Settings
from arena_clients import HttpArenaClient
from arena_clients.proxy_headers import resolve_usage_scope
from model_selector import fetch_available_model_rows, require_available_models

PROBE_CONCURRENCY = 3

PING_TOOL: dict[str, JsonValue] = {
    "type": "function",
    "function": {
        "name": "ping",
        "description": "Reply by calling this tool.",
        "parameters": {"type": "object", "properties": {"ok": {"type": "boolean"}}, "required": ["ok"]},
    },
}
PING_MESSAGE: ChatMessage = {"role": "user", "content": "Call the ping tool with ok=true."}
NAMED_PING: dict[str, JsonValue] = {"type": "function", "function": {"name": "ping"}}


def solid_png(red: int, green: int, blue: int, size: int = 16) -> str:
    """A solid-colour PNG as a data URI."""

    def chunk(kind: bytes, body: bytes) -> bytes:
        return struct.pack(">I", len(body)) + kind + body + struct.pack(">I", zlib.crc32(kind + body))

    row = b"\x00" + bytes((red, green, blue)) * size
    data = (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 2, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(row * size))
        + chunk(b"IEND", b"")
    )
    return "data:image/png;base64," + base64.b64encode(data).decode()


def ping_args_ok(turn: TurnResult) -> bool:
    if len(turn.tool_calls) != 1 or turn.tool_calls[0].name != "ping":
        return False
    try:
        return isinstance(json.loads(turn.tool_calls[0].arguments or "null"), dict)
    except json.JSONDecodeError:
        return False


async def probe_light(llm: LlmClient, model: str, timing: Timing) -> ProbeResult:
    """One tool call with ``tool_choice=auto`` (the loop's mode): is the model reachable, how fast is its first token, does it call tools?"""
    try:
        turn = await llm.stream_turn(
            model,
            [PING_MESSAGE],
            [PING_TOOL],
            timeout_s=timing.probe_timeout_s,
            ttft_budget_s=timing.probe_timeout_s,
            live=False,
        )
    except LlmError as exc:
        # A 401/403/429 or a dropped connection may be a lobby restriction, not a bad model.
        return ProbeResult(model=model, available=not exc.model_gone, error=str(exc))
    unknown = turn.cause != "complete"
    return ProbeResult(model=model, available=True, tool_calls_ok=None if unknown else ping_args_ok(turn), ttft_s=turn.ttft_s)


async def run_light_probe(
    llm: LlmClient,
    book: ModelBook,
    timing: Timing,
    console: Console,
    results: list[ProbeResult],
) -> None:
    """Probe the top-ranked text models in parallel; each result is appended as it arrives so a cancel keeps the partial set."""

    async def one(model: str) -> None:
        result = await probe_light(llm, model, timing)
        results.append(result)
        status = "ok" if result.available and result.tool_calls_ok is not False else f"✗ {result.error or 'no tool call'}"
        console.log("probe", f"🩺 {model}: {status} ttft={result.ttft_s if result.ttft_s is None else round(result.ttft_s, 2)}s")

    await asyncio.gather(*(one(model) for model in book.ranked_text[: timing.probe_models]))


class CapabilityReport(BaseModel):
    """What one proxy model supports; ``None`` means the check did not apply or could not finish."""

    model: str
    plain_ok: bool = False
    ttft_s: float | None = None
    usage_reported: bool = False
    reasoning_field_seen: bool = False
    tools_auto_ok: bool = False
    tools_required_ok: bool = False
    tools_named_ok: bool = False
    roundtrip_ok: bool = False
    reasoning_details_returned: bool = False
    effort_low_ok: bool = False
    vision_ok: bool | None = None
    errors: list[str] = Field(default_factory=list)


async def capability_report(llm: LlmClient, model: str, timing: Timing, *, vision: bool) -> CapabilityReport:
    report = CapabilityReport(model=model)

    async def attempt(
        name: str,
        messages: list[ChatMessage],
        tools: list[dict[str, JsonValue]],
        *,
        tool_choice: str | dict[str, JsonValue] = "auto",
        reasoning_effort: str | None = None,
    ) -> TurnResult | None:
        try:
            return await llm.stream_turn(
                model,
                messages,
                tools,
                tool_choice=tool_choice,
                timeout_s=timing.probe_timeout_s * 2,
                ttft_budget_s=timing.probe_timeout_s * 2,
                reasoning_effort=reasoning_effort,
                live=False,
            )
        except LlmError as exc:
            report.errors.append(f"{name}: {exc}")
            return None

    plain = await attempt("plain", [{"role": "user", "content": "Reply with the single word OK."}], [])
    if plain is not None:
        report.plain_ok = bool(plain.content.strip())
        report.ttft_s = plain.ttft_s
        report.usage_reported = plain.completion_tokens is not None
        report.reasoning_field_seen = bool(plain.reasoning)

    auto = await attempt("tool_choice=auto", [PING_MESSAGE], [PING_TOOL])
    if auto is not None:
        report.tools_auto_ok = auto.cause == "complete" and ping_args_ok(auto)
        report.reasoning_details_returned = bool(auto.reasoning_details)

    required = await attempt("tool_choice=required", [PING_MESSAGE], [PING_TOOL], tool_choice="required")
    if required is not None:
        report.tools_required_ok = required.cause == "complete" and ping_args_ok(required)

    named = await attempt("tool_choice=named", [PING_MESSAGE], [PING_TOOL], tool_choice=NAMED_PING)
    if named is not None:
        report.tools_named_ok = named.cause == "complete" and ping_args_ok(named)

    if auto is not None and auto.cause == "complete" and auto.tool_calls:
        call = auto.tool_calls[0]
        assistant: ChatMessage = {
            "role": "assistant",
            "content": auto.content or None,
            "tool_calls": [{"id": call.id or "call_0", "type": "function", "function": {"name": call.name, "arguments": call.arguments}}],
        }
        if auto.reasoning_details:
            assistant["reasoning_details"] = auto.reasoning_details
        followup = [PING_MESSAGE, assistant, {"role": "tool", "tool_call_id": call.id or "call_0", "content": "pong"}]
        second = await attempt("roundtrip", followup, [PING_TOOL])
        report.roundtrip_ok = second is not None and not second.is_empty

    low = await attempt("effort=low", [{"role": "user", "content": "Reply with the single word OK."}], [], reasoning_effort="low")
    report.effort_low_ok = low is not None and not low.is_empty

    if vision:
        image_message: ChatMessage = {
            "role": "user",
            "content": [
                {"type": "text", "text": "What colour is this image? Reply with one word."},
                {"type": "image_url", "image_url": {"url": solid_png(255, 0, 0)}},
            ],
        }
        seen = await attempt("vision", [image_message], [])
        report.vision_ok = seen is not None and "red" in seen.content.lower()
    return report


async def _main() -> None:
    settings = Settings.from_env()
    console = Console(settings.output_dir, f"{settings.agent_id}-probe")
    http = HttpArenaClient(api_base=settings.api_base, api_key=settings.api_key)
    usage_scope = await asyncio.to_thread(http.fetch_usage_scope) or resolve_usage_scope()
    llm = LlmClient(settings.proxy_host, settings.api_key, settings.agent_id, usage_scope, console, UsageMeter())
    rows = await asyncio.to_thread(fetch_available_model_rows, settings.proxy_host, settings.api_key)
    roster = require_available_models([str(row["id"]) for row in rows])
    catalog = Catalog.load()
    book = ModelBook(roster, rows, catalog)
    timing = Timing()
    gate = asyncio.Semaphore(PROBE_CONCURRENCY)

    async def one(model: str) -> CapabilityReport:
        entry = catalog.lookup(model)
        async with gate:
            report = await capability_report(llm, model, timing, vision=entry is not None and "image" in entry.input_modalities)
        console.log("probe", f"{model}: {report.model_dump_json(exclude={'model'})}")
        return report

    reports = await asyncio.gather(*(one(model) for model in book.ranked_text))
    path = settings.output_dir / "probe-report.json"
    path.write_text(json.dumps([report.model_dump() for report in reports], indent=2), encoding="utf-8")
    console.log("probe", f"report written to {path}")
    console.close()


if __name__ == "__main__":
    asyncio.run(_main())
