"""Pydantic types shared by every gauntlet module."""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, JsonValue, model_validator

ChatMessage = dict[str, JsonValue]


def clue_text(item: JsonValue) -> str:
    if isinstance(item, dict):
        return str(item.get("text") or "").strip()
    return str(item).strip()


class Challenge(BaseModel):
    """An assigned challenge; fields the kit does not know about are kept as extras."""

    model_config = ConfigDict(extra="allow")

    challenge_type: str = ""
    challenge_id: str = ""
    puzzle_id: str = ""
    difficulty: str = ""
    description: str = ""
    rules: str = ""
    prompt: str = ""
    reference_notes: str = ""
    input_image_uri: str = ""
    max_time_s: float = 0
    time_remaining_s: float | None = None
    clues: list[str] = Field(default_factory=list)
    required_tools: list[str] = Field(default_factory=list)

    @model_validator(mode="before")
    @classmethod
    def _normalize(cls, data: dict[str, JsonValue]) -> dict[str, JsonValue]:
        values = {key: value for key, value in data.items() if value is not None}
        if not values.get("prompt") and values.get("edit_prompt"):
            values["prompt"] = values.pop("edit_prompt")
        clues = values.get("clues")
        if isinstance(clues, str):
            clues = [clues]
        if isinstance(clues, list):
            values["clues"] = [text for text in map(clue_text, clues) if text]
        return values


class ToolCall(BaseModel):
    id: str
    name: str
    arguments: str


class TurnResult(BaseModel):
    """One streamed model completion; ``cause`` says why the stream ended."""

    model: str
    content: str = ""
    reasoning: str = ""
    reasoning_details: list[JsonValue] = Field(default_factory=list)
    tool_calls: list[ToolCall] = Field(default_factory=list)
    finish_reason: str = ""
    cause: Literal["complete", "deadline", "ttft_stall"] = "complete"
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    ttft_s: float | None = None
    duration_s: float = 0.0

    @property
    def is_empty(self) -> bool:
        return not (self.content.strip() or self.reasoning.strip() or self.tool_calls)


class ToolResult(BaseModel):
    """A tool call's outcome; ``error`` is set when the call failed in any way."""

    data: dict[str, JsonValue] = Field(default_factory=dict)
    images: list[str] = Field(default_factory=list)
    error: str = ""

    @property
    def ok(self) -> bool:
        return not self.error


class ToolCallRecord(BaseModel):
    name: str
    arguments: dict[str, JsonValue]
    ok: bool
    started_s: float
    duration_s: float
    preview: str


class Candidate(BaseModel):
    """The best answer so far; for images ``answer`` is the image URI."""

    answer: str
    rationale: str = ""
    source: str
    kind: Literal["text", "image"] = "text"

    @property
    def display(self) -> str:
        """The answer for logs; an inline image is summarized instead of printed."""
        if self.answer.startswith("data:"):
            return f"inline image ({len(self.answer) // 1024} KB)"
        return self.answer


class ScoreBreakdown(BaseModel):
    model_config = ConfigDict(extra="allow")

    quality_score: float | None = None
    speed_score: float | None = None
    tools_score: float | None = None
    models_score: float | None = None
    tokens_score: float | None = None
    total_tokens_used: int | None = None
    final_score: float | None = None
    elapsed_ms: int | None = None
    missing_required_tools: list[str] = Field(default_factory=list)
    judge_error: str | None = None
    broadcast_thought_count: int | None = None
    broadcast_penalty_applied: bool | None = None
    judge: dict[str, JsonValue] | None = None


class Receipt(BaseModel):
    model_config = ConfigDict(extra="allow")

    accepted: bool = False
    status: str = ""
    score: ScoreBreakdown | None = None


class ProbeResult(BaseModel):
    """Outcome of one light lobby probe call against a text model."""

    model: str
    available: bool
    # None when the probe ended before the model answered, so tool support is unknown.
    tool_calls_ok: bool | None = None
    ttft_s: float | None = None
    error: str = ""


class TraceEvent(BaseModel):
    t_s: float
    phase: Literal["lobby", "run"]
    kind: str
    text: str
    data: dict[str, JsonValue] = Field(default_factory=dict)


class RunRecord(BaseModel):
    agent_id: str
    challenge: Challenge | None = None
    models: list[str] = Field(default_factory=list)
    answer: str = ""
    rationale: str = ""
    receipt: Receipt | None = None
    tool_calls: list[ToolCallRecord] = Field(default_factory=list)
    stage_s: dict[str, float] = Field(default_factory=dict)
    total_tokens: int = 0
