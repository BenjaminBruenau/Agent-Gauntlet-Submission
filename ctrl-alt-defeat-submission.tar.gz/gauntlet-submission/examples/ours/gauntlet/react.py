"""The text / unknown-challenge loop: stream a turn, run its tool calls, verify, finish before the deadline."""

import asyncio
import json

from pydantic import JsonValue

from .bootstrap import Boot, call_auto_required
from .console import one_line
from .context import RunContext
from .contract import FINAL_ANSWER, THINK
from .finalize import Finalizer
from .llm import LlmError
from .prompts import (
    FINAL_TOOL,
    NO_TOOL_CALL_MESSAGE,
    SYSTEM_PROMPT,
    THINK_TOOL,
    VERIFY_MESSAGE,
    bootstrap_thought,
    clean_answer,
    forced_final_message,
    required_missing_message,
    task_message,
    time_note,
)
from .schemas import Candidate, ChatMessage, ToolCall, TurnResult

NAMED_FINAL: dict[str, JsonValue] = {"type": "function", "function": {"name": FINAL_ANSWER}}
# Reasoning kept from a cut-off turn so the forced final turn does not start from nothing.
UNFINISHED_CHARS = 1500
# A model that ignores the tool protocol this many turns in a row is replaced.
MAX_TOOLLESS_TURNS = 2
# Printed tail of a turn's reasoning; the full text is in the trace.
REASONING_TAIL_CHARS = 300


def assistant_message(turn: TurnResult) -> ChatMessage:
    message: ChatMessage = {"role": "assistant", "content": turn.content or None}
    if turn.tool_calls:
        message["tool_calls"] = [
            {"id": call.id, "type": "function", "function": {"name": call.name, "arguments": call.arguments}}
            for call in turn.tool_calls
        ]
    if turn.reasoning_details:
        message["reasoning_details"] = turn.reasoning_details
    return message


def parse_arguments(call: ToolCall) -> dict[str, JsonValue] | str:
    """The call's JSON arguments, or an error message for the model when they are not a JSON object."""
    try:
        parsed = json.loads(call.arguments or "{}")
    except json.JSONDecodeError as exc:
        return f"arguments are not valid JSON ({exc.msg}); send a complete JSON object"
    return parsed if isinstance(parsed, dict) else "arguments must be a JSON object"


class ReactRun:
    def __init__(self, ctx: RunContext, boot: Boot, finalizer: Finalizer) -> None:
        self._ctx = ctx
        self._boot = boot
        self._finalizer = finalizer
        self._timing = ctx.timing
        self._deadline = boot.deadline
        self._models = ctx.models.text_candidates(boot.deadline.left(), ctx.timing)
        if not self._models:
            raise RuntimeError("no text model is eligible for the tool loop")
        self._model_index = 0
        self._switches = 0
        self._step = 0
        self._last_turn_s = 0.0
        self._verify_rounds = 0
        self._toolless_turns = 0
        self._last_answer: str | None = None
        self._done = False
        self._unfinished = ""
        self._messages: list[ChatMessage] = []
        self._tools = ctx.registry.model_tools() + [FINAL_TOOL] + ([THINK_TOOL] if ctx.settings.think_tool else [])

    @property
    def model(self) -> str:
        return self._models[self._model_index]

    async def run(self) -> None:
        challenge = self._boot.challenge
        registry = self._ctx.registry
        handle = registry.artifacts.shrink(challenge.input_image_uri) if challenge.input_image_uri else ""
        missing = registry.missing_required(challenge.required_tools)
        if missing:
            self._ctx.console.log("loop", f"ℹ️  required tools left for the solver: {', '.join(missing)}")
        task = task_message(challenge, self._boot.clues, str(handle), missing)
        note = time_note(self._deadline.left(), self._deadline.total_s, 1, self._timing, missing)
        self._messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"{task}\n\n{note}"},
        ]
        self._ctx.status.model = self.model
        self._ctx.broadcaster.post(bootstrap_thought(challenge, len(self._boot.clues), self.model))
        while not self._done and self._step < self._timing.max_steps:
            left = self._deadline.left()
            if left <= self._timing.force_final_s:
                break
            if self._step > 0:
                missing = registry.missing_required(challenge.required_tools)
                note = time_note(left, self._deadline.total_s, self._step + 1, self._timing, missing)
                self._ctx.console.trace("note", note)
                self._messages.append({"role": "user", "content": note})
            self._step += 1
            await self._take_turn(max(1.0, left - self._timing.force_final_s))
        if not self._done:
            await self._forced_final()

    async def _take_turn(self, timeout_s: float) -> None:
        turn = await self._model_turn(self._tools, "auto", timeout_s, None)
        self._last_turn_s = turn.duration_s
        self._log_turn(turn)
        if turn.cause == "deadline":
            self._unfinished = (turn.content or turn.reasoning)[-UNFINISHED_CHARS:]
            self._broadcast_turn(turn)
            return
        self._messages.append(assistant_message(turn))
        self._broadcast_turn(turn)
        if not turn.tool_calls:
            self._toolless_turns += 1
            if self._toolless_turns >= MAX_TOOLLESS_TURNS:
                self._toolless_turns = 0
                self._switch_model(f"{turn.model} ignored the tool protocol")
            self._messages.append({"role": "user", "content": NO_TOOL_CALL_MESSAGE})
            return
        self._toolless_turns = 0
        finals = [call for call in turn.tool_calls if call.name == FINAL_ANSWER]
        others = [call for call in turn.tool_calls if call.name != FINAL_ANSWER]
        results = await asyncio.gather(*(self._run_tool(call, timeout_s) for call in others))
        outputs = dict(zip((call.id for call in others), results))
        for call in finals:
            outputs[call.id] = await self._handle_final(call, allow_verify=True)
        for call in turn.tool_calls:
            self._messages.append({"role": "tool", "tool_call_id": call.id, "content": outputs[call.id]})

    async def _model_turn(
        self,
        tools: list[dict[str, JsonValue]],
        tool_choice: str | dict[str, JsonValue],
        timeout_s: float,
        effort: str | None,
    ) -> TurnResult:
        """One turn, moving to the next ranked model when the current one errors, stalls or answers with nothing."""
        while True:
            try:
                turn = await self._ctx.llm.stream_turn(
                    self.model,
                    self._messages,
                    tools,
                    tool_choice=tool_choice,
                    timeout_s=timeout_s,
                    ttft_budget_s=self._timing.ttft_budget_s,
                    reasoning_effort=effort,
                )
            except LlmError as exc:
                reason = str(exc)
            else:
                if turn.cause == "deadline":
                    return turn
                if turn.cause == "ttft_stall":
                    reason = f"{self.model} produced no output within {self._timing.ttft_budget_s:.0f}s"
                elif turn.is_empty:
                    reason = f"{self.model} returned an empty completion"
                else:
                    return turn
            self._switch_model(reason)

    def _switch_model(self, reason: str) -> None:
        if self._switches >= self._timing.max_model_switches or self._model_index + 1 >= len(self._models):
            raise RuntimeError(f"no model left to switch to: {reason}")
        self._switches += 1
        self._model_index += 1
        for message in self._messages:
            message.pop("reasoning_details", None)
        self._ctx.status.model = self.model
        self._ctx.console.log("model", f"🔀 {reason}; switching to {self.model}", model=self.model)

    async def _run_tool(self, call: ToolCall, timeout_s: float) -> str:
        if call.name == THINK:
            arguments = parse_arguments(call)
            thought = arguments.get("thought", "") if isinstance(arguments, dict) else ""
            self._ctx.broadcaster.post(f"Thinking: {str(thought)[: self._timing.broadcast_excerpt_chars]}")
            return "Noted."
        spec = self._ctx.registry.spec_for_model_name(call.name)
        if spec is None:
            return f"ERROR: unknown tool {call.name}"
        arguments = parse_arguments(call)
        if isinstance(arguments, str):
            return f"ERROR: {arguments}"
        result = await self._ctx.registry.call(spec.name, arguments, timeout_s=timeout_s)
        return self._ctx.registry.render(result)

    async def _handle_final(self, call: ToolCall, *, allow_verify: bool) -> str:
        arguments = parse_arguments(call)
        if isinstance(arguments, str):
            return f"ERROR: {arguments}"
        expanded = self._ctx.registry.artifacts.expand_text(clean_answer(str(arguments.get("answer", ""))))
        if not expanded:
            return "ERROR: the answer is empty"
        rationale = str(arguments.get("rationale", ""))
        self._finalizer.offer(Candidate(answer=expanded, rationale=rationale, source=self.model))
        self._ctx.broadcaster.post(f"Answer: {expanded}. {rationale}"[: self._timing.broadcast_excerpt_chars])
        missing = await call_auto_required(self._ctx, self._boot.challenge)
        if missing:
            return required_missing_message(missing)
        changed = expanded != self._last_answer
        self._last_answer = expanded
        if allow_verify and changed and self._can_verify():
            self._verify_rounds += 1
            self._ctx.console.log("verify", f"🔎 verify round {self._verify_rounds}: asking {self.model} to re-check its candidate")
            return VERIFY_MESSAGE
        self._done = True
        return "Final answer accepted."

    def _can_verify(self) -> bool:
        needed = self._timing.force_final_s + self._timing.round_margin * self._last_turn_s
        return self._ctx.settings.verify and self._verify_rounds < self._timing.max_verify_rounds and self._deadline.left() > needed

    async def _forced_final(self) -> None:
        left = self._deadline.left()
        self._ctx.console.log("loop", f"⏱️  {left:.0f}s left: forcing a final answer")
        self._messages.append({"role": "user", "content": forced_final_message(left, self._unfinished)})
        timeout_s = max(1.0, left - self._timing.submit_reserve_s)
        turn = await self._model_turn([FINAL_TOOL], NAMED_FINAL, timeout_s, "low")
        self._log_turn(turn)
        finals = [call for call in turn.tool_calls if call.name == FINAL_ANSWER]
        if finals:
            await self._handle_final(finals[0], allow_verify=False)
        elif self._finalizer.candidate is None:
            partial = next((line for line in reversed((turn.content or self._unfinished).splitlines()) if line.strip()), "")
            if partial:
                self._finalizer.offer(Candidate(answer=clean_answer(partial), source=f"{turn.model} (partial)"))

    def _log_turn(self, turn: TurnResult) -> None:
        console = self._ctx.console
        calls = [{"name": call.name, "arguments": call.arguments} for call in turn.tool_calls]
        ttft = "n/a" if turn.ttft_s is None else f"{turn.ttft_s:.1f}s"
        console.log(
            "turn",
            f"🧠 {turn.model} step {self._step}: {turn.duration_s:.1f}s ttft={ttft} "
            f"tokens={turn.completion_tokens if turn.completion_tokens is not None else '~'} [{turn.cause}]",
            model=turn.model,
            cause=turn.cause,
            content=turn.content,
            reasoning=turn.reasoning,
            tool_calls=calls,
        )
        if turn.reasoning.strip():
            console.log("reasoning", f"💭 …{one_line(turn.reasoning[-REASONING_TAIL_CHARS:], REASONING_TAIL_CHARS)}")
        if turn.content.strip():
            console.log("say", f"💬 {one_line(turn.content, 400)}")
        for call in calls:
            console.log("call", f"🛠️  {call['name']}({one_line(call['arguments'], 300)})")

    def _broadcast_turn(self, turn: TurnResult) -> None:
        """Content first, then a tool-call summary, and raw reasoning only when nothing else exists."""
        limit = self._timing.broadcast_excerpt_chars
        calls = [call for call in turn.tool_calls if call.name != FINAL_ANSWER]  # the answer is broadcast by _handle_final
        if turn.content.strip():
            text = turn.content.strip()
        elif calls:
            text = "Calling " + ", ".join(f"{call.name}({one_line(call.arguments, 80)})" for call in calls)
        else:
            text = turn.reasoning.strip()
        if text:
            self._ctx.broadcaster.post(text[:limit])
