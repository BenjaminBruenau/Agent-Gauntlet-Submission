"""Ctrl Alt Defeat Gauntlet agent.

Importing the package puts the starter-kit root on ``sys.path`` and loads its ``.env``, so the
entry point and ``python -m gauntlet.probe`` find ``arena_clients``, ``model_selector`` and ``my_strategy``.
"""

import sys
from pathlib import Path

from dotenv import load_dotenv

KIT_ROOT = Path(__file__).resolve().parents[3]
if str(KIT_ROOT) not in sys.path:
    sys.path.insert(0, str(KIT_ROOT))
load_dotenv(KIT_ROOT / ".env")
