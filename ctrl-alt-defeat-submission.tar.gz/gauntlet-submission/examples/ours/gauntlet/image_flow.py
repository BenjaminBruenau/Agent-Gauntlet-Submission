"""The image pipeline: edit or generate, check the result, redo with the failures named, submit with an honest rationale."""

import re
import time

from pydantic import BaseModel, Field

from .bootstrap import Boot, call_auto_required
from .console import one_line
from .context import RunContext
from .contract import ANALYSIS_TEXT, IMAGE_URI, MODEL, PROMPT, QUESTION, Role
from .finalize import Finalizer
from .prompts import analysis_question, image_prompt, image_rationale
from .schemas import Candidate, ToolResult

VERDICT_LINE = re.compile(r"VERDICT:\s*(PASS|FAIL)", re.IGNORECASE)
FAIL_LINE = re.compile(r"^\W*(?:\d+[.)]\s*)?FAIL\b\W*", re.IGNORECASE)
# A vision model needs time to read an image; the same cap applies to the tool-less check.
VISION_CHECK_TIMEOUT_S = 30.0


class Verdict(BaseModel):
    """Result of a visual check; ``passed`` is None when the reply carried no parsable verdict."""

    passed: bool | None
    failures: list[str] = Field(default_factory=list)

    @property
    def summary(self) -> str:
        if self.passed is None:
            return "the reply had no verdict line, so the result is unverified"
        if self.passed:
            return "every requirement passed"
        return "failed requirements: " + "; ".join(self.failures or ["unspecified"])

    @property
    def rank(self) -> tuple[int, int]:
        """Higher is better: verified pass, then unverified, then fewer failures."""
        return (2 if self.passed else 1 if self.passed is None else 0, -len(self.failures))


def parse_verdict(text: str) -> Verdict:
    failures = [FAIL_LINE.sub("", line).strip() for line in text.splitlines() if FAIL_LINE.match(line)]
    matches = VERDICT_LINE.findall(text)
    if not matches:
        return Verdict(passed=None, failures=failures)
    return Verdict(passed=matches[-1].upper() == "PASS" and not failures, failures=failures)


class ImageRun:
    def __init__(self, ctx: RunContext, boot: Boot, finalizer: Finalizer) -> None:
        self._ctx = ctx
        self._boot = boot
        self._finalizer = finalizer
        self._timing = ctx.timing
        self._challenge = boot.challenge
        registry = ctx.registry
        self._editing = bool(self._challenge.input_image_uri)
        self._tool = Role.IMAGE_EDIT if self._editing else Role.IMAGE_GENERATE
        if not registry.has(self._tool):
            raise RuntimeError(f"{self._tool} was not discovered, so this image challenge cannot be solved")
        # An empty alias means "let the tool pick its default model".
        self._models = ctx.models.image_candidates(editing=self._editing) or [""]
        self._vision_model = None if registry.has(Role.IMAGE_ANALYZE) else ctx.models.vision_model()
        self._checker = Role.IMAGE_ANALYZE.value if registry.has(Role.IMAGE_ANALYZE) else (self._vision_model or "")

    async def run(self) -> None:
        challenge, deadline, timing = self._challenge, self._boot.deadline, self._timing
        approach = f"{self._tool.value} with {self._models[0] or 'the default model'}"
        checker = f"check with {self._checker}" if self._checker else "no automated check available"
        self._ctx.broadcaster.post(
            f"Plan: {approach} for '{one_line(challenge.prompt or challenge.description, 120)}', then {checker}, redo up to "
            f"{timing.max_image_redos} times if it fails, then submit."
        )
        model_index = 0
        failures: list[str] = []
        best: tuple[tuple[int, int, int], Candidate] | None = None
        last_round_s = 0.0
        for attempt in range(1, timing.max_image_redos + 2):
            if attempt > 1 and deadline.left() < timing.round_margin * last_round_s + timing.submit_reserve_s:
                self._ctx.console.log("image", f"⏱️  {deadline.left():.0f}s left: no time for another attempt")
                break
            round_started = time.monotonic()
            produced = await self._produce(image_prompt(challenge, failures), model_index)
            if produced is None:
                break
            uri, model_index = produced
            self._ctx.status.model = self._models[model_index]
            if best is None:
                self._finalizer.offer(self._candidate(uri, model_index, attempt, "the check did not finish before submission"))
            verdict = await self._check(uri)
            candidate = self._candidate(uri, model_index, attempt, verdict.summary if verdict else "the check could not be run")
            score = ((verdict.rank if verdict else (1, 0)) + (attempt,))
            if best is None or score > best[0]:
                best = (score, candidate)
                self._finalizer.offer(candidate)
            last_round_s = time.monotonic() - round_started
            if verdict is None or verdict.passed is not False:
                break
            failures = verdict.failures
        if best is None:
            self._last_resort()
        await call_auto_required(self._ctx, challenge)

    def _candidate(self, uri: str, model_index: int, attempt: int, check_summary: str) -> Candidate:
        model = self._models[model_index] or "the default model"
        rationale = image_rationale(
            self._challenge, tool=self._tool.value, model=model, attempt=attempt, checker=self._checker, check_summary=check_summary
        )
        return Candidate(answer=uri, rationale=rationale, source=f"{model} attempt {attempt}", kind="image")

    def _last_resort(self) -> None:
        """Every image model failed. An edit can still submit the untouched input, honestly labelled; a generation has nothing to submit."""
        if not self._editing:
            self._ctx.console.log("image", "⚠️  no image was produced and there is no input to fall back on")
            return
        self._ctx.console.log("image", "⚠️  every image model failed: submitting the unmodified input image")
        self._finalizer.offer(
            Candidate(
                answer=self._challenge.input_image_uri,
                rationale="Every image model failed to return an edited image, so this is the unmodified input; the requested edit was not applied.",
                source="input image",
                kind="image",
            )
        )

    async def _produce(self, prompt: str, start_index: int) -> tuple[str, int] | None:
        """Run the image tool, moving to the next model when it errors or returns no image."""
        registry = self._ctx.registry
        for index in range(start_index, len(self._models)):
            model = self._models[index]
            arguments: dict[str, str] = {PROMPT: prompt}
            if self._editing:
                arguments[IMAGE_URI] = self._challenge.input_image_uri
            if model and registry.accepts(self._tool.value, MODEL):
                arguments[MODEL] = model
            result = await registry.call(self._tool.value, arguments, timeout_s=self._tool_timeout())
            uri = self._image_uri(result)
            if uri:
                self._ctx.broadcaster.post(f"{self._tool.value} produced an image with {model or 'the default model'}; checking it.")
                return uri, index
            self._ctx.console.log("image", f"⚠️  {model or 'default model'} gave no image: {one_line(result.error or str(result.data), 160)}")
        return None

    def _tool_timeout(self) -> float:
        return max(1.0, self._boot.deadline.left() - self._timing.submit_reserve_s)

    @staticmethod
    def _image_uri(result: ToolResult) -> str:
        if not result.ok:
            return ""
        return str(result.data.get(IMAGE_URI) or "") or (result.images[0] if result.images else "")

    async def _check(self, uri: str) -> Verdict | None:
        question = analysis_question(self._challenge)
        text = await self._ask_analyzer(uri, question)
        if text is None:
            return None
        verdict = parse_verdict(text)
        self._ctx.console.log("image", f"🔍 check: {verdict.summary} | analyzer said: {one_line(text, 300)}", analyzer_reply=text)
        self._ctx.broadcaster.post(f"Check of the image: {verdict.summary}")
        return verdict

    async def _ask_analyzer(self, uri: str, question: str) -> str | None:
        registry = self._ctx.registry
        if registry.has(Role.IMAGE_ANALYZE):
            result = await registry.call(Role.IMAGE_ANALYZE.value, {IMAGE_URI: uri, QUESTION: question}, timeout_s=self._tool_timeout())
            return str(result.data.get(ANALYSIS_TEXT) or "") if result.ok else None
        if self._vision_model is None:
            return None
        turn = await self._ctx.llm.stream_turn(
            self._vision_model,
            [{"role": "user", "content": [{"type": "text", "text": question}, {"type": "image_url", "image_url": {"url": uri}}]}],
            [],
            timeout_s=min(VISION_CHECK_TIMEOUT_S, self._tool_timeout()),
            ttft_budget_s=self._timing.ttft_budget_s,
        )
        return turn.content if turn.cause == "complete" else None
