"""Console output and JSONL trace, written from a background thread so the agent loop never waits on I/O."""

import queue
import re
import threading
import time
from dataclasses import dataclass
from pathlib import Path

from arena_clients.display import ReasoningTicker
from pydantic import JsonValue

from .schemas import Challenge, Receipt, TraceEvent

TICK_INTERVAL_S = 0.25
PREVIEW_CHARS = 240


def one_line(text: str, limit: int = PREVIEW_CHARS) -> str:
    flat = re.sub(r"\s+", " ", text).strip()
    return flat if len(flat) <= limit else flat[: limit - 1] + "…"


def challenge_lines(challenge: Challenge) -> list[str]:
    head = " · ".join(
        part
        for part in (
            challenge.puzzle_id,
            challenge.challenge_type,
            challenge.difficulty,
            f"time limit {challenge.max_time_s:g}s" if challenge.max_time_s else "",
        )
        if part
    )
    lines = [f"🎯 Challenge  {head}"]
    task = challenge.prompt or challenge.description
    lines.append(f"   Task       {one_line(task)}")
    if challenge.rules and challenge.rules != task:
        lines.append(f"   Answer as  {one_line(challenge.rules)}")
    if challenge.reference_notes:
        lines.append(f"   Notes      {one_line(challenge.reference_notes)}")
    if challenge.input_image_uri:
        lines.append("   Input      an image to edit")
    if challenge.clues:
        lines.append(f"   Clues      {len(challenge.clues)}")
    if challenge.required_tools:
        lines.append(f"   Must call  {', '.join(challenge.required_tools)}")
    return lines


def score_lines(receipt: Receipt) -> list[str]:
    lines = [f"📊 Receipt    accepted={receipt.accepted}" + (f" status={receipt.status}" if receipt.status else "")]
    score = receipt.score
    if score is None:
        return lines
    fields = score.model_dump(exclude_none=True)
    judge = fields.pop("judge", None)
    fields.pop("output_image_uri", None)
    missing = fields.pop("missing_required_tools", [])
    lines.extend(f"   {key:<26}{value}" for key, value in fields.items())
    if missing:
        lines.append(f"   ⚠️  missing required tools: {', '.join(missing)}")
    if judge:
        lines.append(f"   {'judge':<26}{one_line(str(judge), 600)}")
    return lines


@dataclass(frozen=True)
class _Line:
    event: TraceEvent
    show: bool


@dataclass(frozen=True)
class _Tick:
    model: str
    reasoning: str
    answer: str


@dataclass(frozen=True)
class _TickEnd:
    pass


class Console:
    def __init__(self, output_dir: Path, agent_id: str) -> None:
        self._queue: queue.SimpleQueue[_Line | _Tick | _TickEnd | None] = queue.SimpleQueue()
        self._started = time.monotonic()
        self._go_at: float | None = None
        self._trace_path = output_dir / f"{agent_id}-trace.jsonl"
        self._pending_reasoning = ""
        self._pending_answer = ""
        self._last_tick = 0.0
        self._thread = threading.Thread(target=self._drain, name="console", daemon=True)
        self._thread.start()

    def mark_go(self) -> None:
        self._go_at = time.monotonic()

    def log(self, kind: str, text: str, **data: JsonValue) -> None:
        """Print one line and record it in the trace."""
        self._queue.put(self._line(kind, text, data, show=True))

    def trace(self, kind: str, text: str = "", **data: JsonValue) -> None:
        """Record in the trace only."""
        self._queue.put(self._line(kind, text, data, show=False))

    def stream(self, model: str, reasoning: str, answer: str) -> None:
        """Feed the live reasoning line; deltas are batched so the queue sees about four items a second."""
        self._pending_reasoning += reasoning
        self._pending_answer += answer
        now = time.monotonic()
        if now - self._last_tick >= TICK_INTERVAL_S:
            self._flush_stream(model)
            self._last_tick = now

    def stream_end(self, model: str) -> None:
        self._flush_stream(model)
        self._queue.put(_TickEnd())

    def close(self) -> None:
        self._queue.put(None)
        self._thread.join(timeout=3.0)

    def _line(self, kind: str, text: str, data: dict[str, JsonValue], *, show: bool) -> _Line:
        now = time.monotonic()
        if self._go_at is None:
            event = TraceEvent(t_s=now - self._started, phase="lobby", kind=kind, text=text, data=data)
        else:
            event = TraceEvent(t_s=now - self._go_at, phase="run", kind=kind, text=text, data=data)
        return _Line(event, show)

    def _flush_stream(self, model: str) -> None:
        if self._pending_reasoning or self._pending_answer:
            self._queue.put(_Tick(model, self._pending_reasoning, self._pending_answer))
            self._pending_reasoning = ""
            self._pending_answer = ""

    def _drain(self) -> None:
        self._trace_path.parent.mkdir(parents=True, exist_ok=True)
        ticker: ReasoningTicker | None = None
        with self._trace_path.open("w", encoding="utf-8") as trace:
            while (item := self._queue.get()) is not None:
                if isinstance(item, _Tick):
                    if ticker is None or ticker.model != item.model:
                        ticker = ReasoningTicker(item.model)
                    ticker.feed(reasoning=item.reasoning, answer=item.answer)
                    continue
                if ticker is not None:
                    ticker.finish()
                if isinstance(item, _TickEnd):
                    ticker = None
                    continue
                trace.write(item.event.model_dump_json() + "\n")
                trace.flush()
                if item.show:
                    event = item.event
                    stamp = f"[lobby {event.t_s:5.1f}s]" if event.phase == "lobby" else f"[+{event.t_s:5.1f}s]"
                    for line in event.text.splitlines():
                        print(f"{stamp} {line}", flush=True)
