"""Background reporting to the Arena: broadcast thoughts and live status. Neither ever blocks the agent loop."""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable

from arena_clients import ArenaAPIError, ArenaConnectionError, HttpArenaClient, McpArenaError
from mcp.shared.exceptions import McpError

from .console import Console, one_line
from .llm import UsageMeter

REPORT_ERRORS = (ArenaAPIError, ArenaConnectionError, McpArenaError, McpError)


class Broadcaster:
    """Sends thoughts in order from one worker task; ``acked`` counts server acknowledgements."""

    def __init__(self, send: Callable[[str], Awaitable[bool]], console: Console) -> None:
        self._send = send
        self._console = console
        self._queue: asyncio.Queue[str] = asyncio.Queue()
        self._task: asyncio.Task[None] | None = None
        self.acked = 0

    def start(self) -> None:
        self._task = asyncio.create_task(self._run())

    def post(self, text: str) -> None:
        self._queue.put_nowait(text)

    async def drain(self, timeout_s: float) -> None:
        try:
            await asyncio.wait_for(self._queue.join(), timeout_s)
        except TimeoutError:
            self._console.log("broadcast", "⚠️  broadcast queue still pending", pending=self._queue.qsize())

    async def ensure_min(self, minimum: int, timeout_s: float) -> None:
        """Wait for queued thoughts, then send one directly if the server has acknowledged fewer than ``minimum``."""
        await self.drain(timeout_s)
        if self.acked < minimum:
            try:
                await asyncio.wait_for(self._deliver("Submitting final answer."), timeout_s)
            except TimeoutError:
                self._console.log("broadcast", "⚠️  no broadcast acknowledged before submit")

    async def stop(self) -> None:
        if self._task is not None:
            self._task.cancel()
            await asyncio.gather(self._task, return_exceptions=True)

    async def _run(self) -> None:
        while True:
            text = await self._queue.get()
            await self._deliver(text)
            self._queue.task_done()

    async def _deliver(self, text: str) -> None:
        try:
            accepted = await self._send(text)
        except REPORT_ERRORS as exc:
            self._console.log("broadcast", f"⚠️  broadcast failed: {one_line(str(exc), 120)}")
            return
        if accepted:
            self.acked += 1
        self._console.log("broadcast", f"📣 {one_line(text, 300)}" + ("" if accepted else " (not acknowledged)"), thought=text, accepted=accepted)


class StatusReporter:
    """Pushes model, tokens and elapsed time to the dashboard once per interval."""

    def __init__(
        self,
        http: HttpArenaClient,
        agent_id: str,
        meter: UsageMeter,
        interval_s: float,
        console: Console,
    ) -> None:
        self._http = http
        self._agent_id = agent_id
        self._meter = meter
        self._interval_s = interval_s
        self._console = console
        self._started = time.monotonic()
        self._task: asyncio.Task[None] | None = None
        self.model = ""

    def start(self) -> None:
        self._started = time.monotonic()
        self._task = asyncio.create_task(self._run())

    def client_metrics(self) -> dict[str, str | int]:
        """The metrics shape the Arena expects, also attached to the final submission."""
        return {
            "model_name": self.model,
            "total_tokens": str(self._meter.total_tokens),
            "prompt_tokens": str(self._meter.prompt_tokens),
            "completion_tokens": str(self._meter.completion_tokens),
            "total_time_ms": int((time.monotonic() - self._started) * 1000),
        }

    async def stop(self) -> None:
        if self._task is not None:
            self._task.cancel()
            await asyncio.gather(self._task, return_exceptions=True)

    async def _run(self) -> None:
        while True:
            try:
                await asyncio.to_thread(self._http.update_status, self._agent_id, "running", self.client_metrics())
            except (ArenaAPIError, ArenaConnectionError) as exc:
                self._console.trace("status", f"status update failed: {exc}")
            await asyncio.sleep(self._interval_s)
