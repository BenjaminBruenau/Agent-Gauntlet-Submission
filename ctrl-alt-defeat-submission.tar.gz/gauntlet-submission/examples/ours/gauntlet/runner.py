"""One heat from registration to the printed receipt."""

from __future__ import annotations

import asyncio

from arena_clients import HttpArenaClient, McpArenaClient, ensure_connected, monitor_session
from arena_clients.proxy_headers import resolve_usage_scope

from .bootstrap import Boot, bootstrap
from .clock import Timing
from .console import Console, challenge_lines, score_lines
from .context import RunContext
from .contract import Role
from .finalize import Finalizer, image_submitter, solve_then_submit, text_submitter
from .image_flow import ImageRun
from .lobby import LOBBY_PHASE, current_phase, discover_roster, wait_for_go
from .llm import LlmClient, UsageMeter
from .mcp_tools import ArtifactStore, ToolRegistry
from .models import Catalog, ModelBook
from .probe import run_light_probe
from .react import ReactRun
from .schemas import ProbeResult, Receipt, RunRecord
from .settings import Settings
from .telemetry import Broadcaster, StatusReporter

IMAGE_THOUGHT_ARGUMENT = "thought"


async def run() -> None:
    settings = Settings.from_env()
    console = Console(settings.output_dir, settings.agent_id)
    try:
        await _run(settings, Timing(), console)
    finally:
        console.close()


async def _run(settings: Settings, timing: Timing, console: Console) -> None:
    console.log("start", f"🤖 {settings.agent_name} ({settings.agent_id}) · API {settings.api_base} · MCP {settings.mcp_url} · LLM {settings.proxy_host}")
    ensure_connected()
    http = HttpArenaClient(api_base=settings.api_base, api_key=settings.api_key)
    session = await asyncio.to_thread(http.register, settings.agent_id, settings.agent_name)
    console.log("lobby", f"📝 registered: session {session.session_id} ({session.status})")
    async with monitor_session(http, settings.agent_id), McpArenaClient(settings.mcp_url) as mcp:
        await _heat(settings, timing, console, http, mcp)


async def _heat(settings: Settings, timing: Timing, console: Console, http: HttpArenaClient, mcp: McpArenaClient) -> None:
    meter = UsageMeter()
    usage_scope = await asyncio.to_thread(http.fetch_usage_scope) or resolve_usage_scope()
    llm = LlmClient(settings.proxy_host, settings.api_key, settings.agent_id, usage_scope, console, meter)
    registry = ToolRegistry(
        mcp,
        agent_id=settings.agent_id,
        image_model=settings.image_model,
        timing=timing,
        console=console,
        artifacts=ArtifactStore(),
    )
    registry.load(await mcp.list_tool_defs())
    console.log("lobby", f"🧰 tools: {', '.join(sorted(registry.names))}")
    rows = await discover_roster(settings.proxy_host, settings.api_key, console)
    roster = [str(row["id"]) for row in rows]
    book = ModelBook(roster, rows, Catalog.load(), forced_text=settings.text_model, forced_image=settings.image_model)
    console.log("lobby", f"🏆 {book.describe()}")
    status = StatusReporter(http, settings.agent_id, meter, timing.status_interval_s, console)

    async def send_thought(text: str) -> bool:
        if ctx.modality == "image" and registry.has(Role.IMAGE_BROADCAST):
            result = await registry.call(Role.IMAGE_BROADCAST.value, {IMAGE_THOUGHT_ARGUMENT: text}, quiet=True)
            return result.ok
        return await asyncio.to_thread(http.broadcast_thought, settings.agent_id, text)

    broadcaster = Broadcaster(send_thought, console)
    ctx = RunContext(settings, timing, console, http, mcp, registry, llm, book, broadcaster, status)
    ctx.modality = await asyncio.to_thread(McpArenaClient.detect_modality, sorted(registry.names), settings.agent_id)
    console.log("lobby", f"🎯 assignment: {ctx.modality}")

    probe: asyncio.Task[None] | None = None
    probe_results: list[ProbeResult] = []
    if settings.lobby_probe and await current_phase(http) == LOBBY_PHASE:
        probe = asyncio.create_task(run_light_probe(llm, book, timing, console, probe_results))
    await wait_for_go(http, console, timing, probe)
    if probe is not None:
        await asyncio.gather(probe, return_exceptions=True)
        book.apply_probes(probe_results)
    console.mark_go()
    console.log("go", "🚀 GO")
    broadcaster.start()
    status.start()
    scope_task = asyncio.create_task(asyncio.to_thread(http.fetch_usage_scope))

    boot = await bootstrap(ctx)
    scope = await scope_task
    if scope:
        llm.set_usage_scope(scope)
    boot_s = boot.deadline.elapsed()
    console.log("challenge", "\n".join(challenge_lines(boot.challenge)))
    console.log("bootstrap", f"⚡ ready {boot_s:.1f}s after GO with {len(boot.clues)} clues; {boot.deadline.left():.0f}s left")

    has_image_flow = (
        ctx.modality == "image"
        and registry.has(Role.IMAGE_SUBMIT)
        and (registry.has(Role.IMAGE_EDIT) or registry.has(Role.IMAGE_GENERATE))
    )
    editing = bool(boot.challenge.input_image_uri)
    registry.image_model = registry.image_model or next(iter(book.image_candidates(editing=editing)), "")
    finalizer = Finalizer(
        image_submitter(mcp, http, settings.agent_id, status, console)
        if has_image_flow
        else text_submitter(http, settings.agent_id, status, "image" if ctx.modality == "image" else None),
        broadcaster,
        console,
        timing,
    )
    solver = ImageRun(ctx, boot, finalizer).run() if has_image_flow else ReactRun(ctx, boot, finalizer).run()
    try:
        receipt = await solve_then_submit(solver, boot.deadline, timing, finalizer, console)
    finally:
        await status.stop()
    await broadcaster.drain(timing.submit_reserve_s)
    await broadcaster.stop()
    _report(settings, console, boot, finalizer, receipt, registry, status, meter, boot_s)


def _report(
    settings: Settings,
    console: Console,
    boot: Boot,
    finalizer: Finalizer,
    receipt: Receipt | None,
    registry: ToolRegistry,
    status: StatusReporter,
    meter: UsageMeter,
    boot_s: float,
) -> None:
    if receipt is not None:
        console.log("receipt", "\n".join(score_lines(receipt)))
    try:
        candidate = finalizer.candidate
        answer = "" if candidate is None else candidate.answer
        challenge = boot.challenge
        if challenge.input_image_uri.startswith("data:"):
            challenge = challenge.model_copy(update={"input_image_uri": "(inline image)"})
        record = RunRecord(
            agent_id=settings.agent_id,
            challenge=challenge,
            models=[status.model],
            answer=f"(inline image, {len(answer)} chars)" if answer.startswith("data:") else answer,
            rationale="" if candidate is None else candidate.rationale,
            receipt=receipt,
            tool_calls=registry.records,
            stage_s={"go_to_ready": boot_s, "total": boot.deadline.elapsed()},
            total_tokens=meter.total_tokens,
        )
        path = settings.output_dir / f"{settings.agent_id}-run.json"
        path.write_text(record.model_dump_json(indent=2), encoding="utf-8")
    except Exception as exc:
        console.log("done", f"⚠️  run record not saved: {exc}")
    else:
        console.log("done", f"✅ run record: {path}")
